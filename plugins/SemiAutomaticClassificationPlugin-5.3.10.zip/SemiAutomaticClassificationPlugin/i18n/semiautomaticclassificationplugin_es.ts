<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="es" sourcelanguage="">
<context>
    <name>DockClass</name>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="20"/>
        <source>SCP Dock</source>
        <translation>SCP Panel</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="42"/>
        <source>SCP input</source>
        <translation>SCP entrada de datos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="61"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Band calc&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Calculadora de Bandas&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="81"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Tools&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Herramientas&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="101"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preprocessing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preprocesamiento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="121"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Preferencias&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="141"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Postprocessing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Postprocesamiento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="174"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;User manual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Manual del Usuario&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="207"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Online help&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Ayuda en línea&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="227"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Download images&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Descarga imágenes&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="271"/>
        <source> Training input</source>
        <translation> Entrenamiento de Entrada</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="285"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Input file path&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ruta de archivo de Entrada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="292"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Open a training input&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Abrir un Entrenamiento de Entrada&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Create a new training input&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Crear un nuevo Entrenamiento de Entrada&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="336"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Refresh list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Recargar lista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1311"/>
        <source>Plot</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Band set&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Juego de Bandas&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="379"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an image&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona una imagen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="386"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open a file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abrir archivo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="422"/>
        <source> Input image</source>
        <translation> Imagen de Entrada</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="465"/>
        <source> SCP news</source>
        <translation> SCP noticias</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="486"/>
        <source>Classification dock</source>
        <translation>Panel para Clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="519"/>
        <source> ROI Signature list</source>
        <translation> ROI listado de Firmas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="557"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="562"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1648"/>
        <source>MC ID</source>
        <translation>MC ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1664"/>
        <source>C ID</source>
        <translation>C ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="986"/>
        <source>C Info</source>
        <translation>C Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1372"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="609"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add highlighted items to scatter plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agregar al gráfico de dispersión los elementos seleccionados&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="702"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="647"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import spectral signatures &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar firmas espectrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1972"/>
        <source>Import library</source>
        <translation>Importar librería</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="670"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Export highlighted spectral signatures&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Exportar las firmas espectrales seleccionadas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="696"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Delete highlighted items&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suprimir los elementos seleccionados&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="719"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate signatures for highlighted items&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular firmas para los elementos seleccionados&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="742"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Merge highlighted spectral signatures obtaining the average signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Combinar las firmas espectrales seleccionadas para obtener la firma promedio&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="765"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add highlighted signatures to spectral signature plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Agregar las firmas espectrales seleccionadas al gráfico de firmas espectrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="824"/>
        <source>ROI creation</source>
        <translation>Creación de ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="841"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display a vegetation index value with the cursor&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mostrar el índice de vegetación con el cursor&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="844"/>
        <source>Display</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="854"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a vegetation index&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el índice de vegetación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="858"/>
        <source>NDVI</source>
        <translation>NDVI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="863"/>
        <source>EVI</source>
        <translation>EVI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="868"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="876"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Custom expression (e.g. bandset#b4 / bandset#b3 )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Expresión personalizada (Ej. bandset#b4 / bandset#b3 )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="898"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The class name of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;El nombre de Clase de la Firma del ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="901"/>
        <source>C 1</source>
        <translation>C 1</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="923"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The macroclass ID of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;La ID de la Macroclase de la firma del ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="948"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The macroclass name of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;El nombre de la Macroclase de la firma del ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="951"/>
        <source>MC 1</source>
        <translation>MC 1</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1367"/>
        <source>MC Info</source>
        <translation>MC Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1037"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The class ID of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;La ID de la Clase de la firma del ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1060"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Undo ROI save&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Deshacer ROI guardado&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1096"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add ROI spectral signature to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agregar firma espectral al ROI en la lista de firmas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1099"/>
        <source>Calculate sig.</source>
        <translation>Calcular firm.</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Save temporary ROI to training input&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Guardar el ROI temporal en el Entrenamiento de Entrada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1138"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically refresh the temporary ROI, as the parameters change&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Actualizar automáticamente el ROI temporal, cuando cambien los parámetros&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1141"/>
        <source>Automatic refresh ROI</source>
        <translation>Actualizar automáticamente el ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Band number&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número de Banda&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1178"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate temporary ROI only on one band&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular el ROI temporal en una sola banda&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1181"/>
        <source>Rapid ROI band</source>
        <translation>ROI rápido en una banda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1190"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically calculate signature plot of temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular automáticamente el gráfico de firmas del ROI temporal&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1193"/>
        <source>Automatic  plot</source>
        <translation>Gráfico automático</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1220"/>
        <source> Macroclasses</source>
        <translation> Macroclases</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1255"/>
        <source>Classification style</source>
        <translation>Estilo de la clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Agregar fila&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1305"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Eliminar fila&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1401"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Qml file path&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ruta a archivo qml&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Reset&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Restablecer&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1437"/>
        <source>Load qml</source>
        <translation>Cargar archivo qml</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1444"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Select qml style&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Seleccionar estilo desde archivo qml&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1483"/>
        <source> Classification algorithm</source>
        <translation>Algoritmo de clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1532"/>
        <source>Threshold</source>
        <translation>Umbral</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1551"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a classification algorithm&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar un algoritmo de clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1555"/>
        <source>Minimum Distance</source>
        <translation>Distancia mínima</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1560"/>
        <source>Maximum Likelihood</source>
        <translation>Máxima Probabilidad</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1565"/>
        <source>Spectral Angle Mapping</source>
        <translation>Mapeo del Angulo Espectral</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1585"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a classification threshold for all signatures&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer el umbral de clasificación para todas las firmas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1601"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open tab Signature threshold&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abrir la pestaña Umbrales de Firmas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1690"/>
        <source>W</source>
        <translation>W</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1745"/>
        <source>Use</source>
        <translation>Usar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1645"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the ID of macroclasses for the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar las ID de las macroclases para la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1661"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the ID of classes for the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar las ID de las clases para la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1684"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open tab Algorithm band weight&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abrir pestaña del Algoritmo de peso de banda&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1725"/>
        <source> Algorithm</source>
        <translation> Algoritmo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1752"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the Land Cover Signature Classification is used&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, se usará la Clasificación de Firmas de Cobertura Terrestre&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1755"/>
        <source>LCS</source>
        <translation>LCS</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1762"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the selected Algorithm is used for unclassified pixels of the Land Cover Signature Classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, el Algoritmo elegido se usará para los pixeles no clasificados de la Clasificación de Firmas de la Cobertura Terrestre&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1765"/>
        <source>Algorithm</source>
        <translation>Algoritmo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1772"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the selected Algorithm is used only for class overlapping pixels of the Land Cover Signature Classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, el Algoritmo elegido se usará solo para las Clases que se sobreponen con pixeles de la Clasificación de Firmas de la Cobertura Terrestre&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1775"/>
        <source>only overlap</source>
        <translation>solo sobreposición</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1782"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open tab LCS threshold&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abrir pestaña Umbral de Firmas de Cobertura del Suelo LCS-Land Cover Signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1821"/>
        <source> Land Cover Signature Classification</source>
        <translation> Clasificación de Firmas de la Cobertura Terrestre</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1849"/>
        <source> Classification output</source>
        <translation> Resultado de la Clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1873"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an optional mask vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar una máscara vectorial opcional&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1876"/>
        <source>Apply mask</source>
        <translation>Aplicar máscara</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Path of the optional mask shapefile&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ruta al archivo de máscara shape opcional&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1928"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create a classification shapefile after the classification process&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crear un archivo shape después del proceso de clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1931"/>
        <source>Create vector</source>
        <translation>Crear vector</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1938"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate a classification report&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular un reporte de la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1941"/>
        <source>Classification report</source>
        <translation>Reporte de la clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1952"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, the rasters calculated by the classification algorithm (one per signature) are saved along with the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si se selecciona, los rásters resultado de la clasificación (uno por Firma) son guardados con la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1955"/>
        <source>Save algorithm files</source>
        <translation>Guardar archivos de algoritmos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1966"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Run&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Ejecutar&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ScatterPlot</name>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="20"/>
        <source>SCP: Scatter Plot</source>
        <translation>SCP: Gráfico de Dispersión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="68"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="73"/>
        <source>MC ID</source>
        <translation>MC ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="78"/>
        <source>MC Info</source>
        <translation>MC Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="83"/>
        <source>C ID</source>
        <translation>C ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="88"/>
        <source>C Info</source>
        <translation>C Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="93"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="150"/>
        <source> Scatter raster</source>
        <translation> Ráster de Dispersión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="168"/>
        <source>Calculate</source>
        <translation>Calcular</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="175"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcula el gráfico de dispersión&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="201"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate and display scatter raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcula y muestra el ráster de dispersión&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="224"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate and save to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcula y guarda en la lista de firmas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="275"/>
        <source>x=0.000000 y=0.000000</source>
        <translation>x=0.000000 y=0.000000</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="284"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically fit the plot to data&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ajusta el gráfico a los datos automaticamente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="307"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save the plot to file (jpg, png, pdf)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Guarda el gráfico en un archivo (jpg, png, pdf)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="348"/>
        <source> Plot</source>
        <translation> Gráfico</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="366"/>
        <source>Colormap</source>
        <translation>Rampa de color</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="385"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a colormap&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona una rampa de color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="395"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set colormap for highlighted spectral plots&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asigna rampa de colores al gráfico espectral seleccionado&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="428"/>
        <source>Extent</source>
        <translation>Extensión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="441"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select extent of scatter raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona la extensión del ráster de dispersión&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="448"/>
        <source>same as display</source>
        <translation>igual a pantalla</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="453"/>
        <source>same as image</source>
        <translation>igual a imagen</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="467"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create selection polygons&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crear polígonos de selección&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="496"/>
        <source>color</source>
        <translation>color</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="503"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select polygon color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar color del polígono&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="516"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove selection polygons&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quitar polígonos de selección&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="546"/>
        <source>Band Y</source>
        <translation>Banda Y</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="571"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Band Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Banda Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="600"/>
        <source>Band X</source>
        <translation>Banda X</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="625"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Band X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Banda X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="648"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use custom decimal precision&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar precisión decimal personalizada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="651"/>
        <source>Precision</source>
        <translation>Precisión</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="658"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select decimal precision:&lt;/p&gt;&lt;p&gt;4 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−4&lt;/span&gt;&lt;/p&gt;&lt;p&gt;3 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−3&lt;/span&gt;&lt;/p&gt;&lt;p&gt;2 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−2&lt;/span&gt;&lt;/p&gt;&lt;p&gt;1 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−1&lt;/span&gt;&lt;/p&gt;&lt;p&gt;0 = 1&lt;/p&gt;&lt;p&gt;-1 = 10&lt;/p&gt;&lt;p&gt;-2 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;2&lt;/span&gt;&lt;/p&gt;&lt;p&gt;-3 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;3&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar precisión decimal:&lt;/p&gt;&lt;p&gt;4 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−4&lt;/span&gt;&lt;/p&gt;&lt;p&gt;3 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−3&lt;/span&gt;&lt;/p&gt;&lt;p&gt;2 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−2&lt;/span&gt;&lt;/p&gt;&lt;p&gt;1 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−1&lt;/span&gt;&lt;/p&gt;&lt;p&gt;0 = 1&lt;/p&gt;&lt;p&gt;-1 = 10&lt;/p&gt;&lt;p&gt;-2 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;2&lt;/span&gt;&lt;/p&gt;&lt;p&gt;-3 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;3&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="665"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="670"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="675"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="680"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="685"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="690"/>
        <source>-1</source>
        <translation>-1</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="695"/>
        <source>-2</source>
        <translation>-2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="700"/>
        <source>-3</source>
        <translation>-3</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="725"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Suprimir fila&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="731"/>
        <source>Plot</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="748"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot from temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular gráfico de dispersión desde el ROI temporal&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="771"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot from the current display extent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular el gráfico de dispersión para la extensión actual de la pantalla&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="794"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot from entire image&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular el gráfico de dispersión para toda la imagen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="843"/>
        <source> Scatter list</source>
        <translation> Listado de dispersión</translation>
    </message>
</context>
<context>
    <name>SemiAutomaticClassificationPlugin</name>
    <message>
        <location filename="input.py" line="143"/>
        <source>RGB = </source>
        <translation>RGB = </translation>
    </message>
    <message>
        <location filename="input.py" line="158"/>
        <source>ROI     </source>
        <translation>ROI     </translation>
    </message>
    <message>
        <location filename="input.py" line="178"/>
        <source>Preview </source>
        <translation>Previa </translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17344"/>
        <source>Semi-Automatic Classification Plugin</source>
        <translation>Semi-Automatic Classification Plugin</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="70"/>
        <source>Download images</source>
        <translation>Descarga de Imágenes</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="90"/>
        <source>Landsat download</source>
        <translation>Descargar Landsat</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4374"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preprocess images&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preprocesar imágenes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4377"/>
        <source>Preprocess images</source>
        <translation>Preprocesar imágenes</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4387"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Load images in QGIS after download&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cargar imágenes en QGIS después de la descarga&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4390"/>
        <source>Load bands in QGIS</source>
        <translation>Cargar bandas en QGIS</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4400"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download images from list only if the corresponding previews are loaded in QGIS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Descarga imágenes solo si su correspondiente vista previa está cargada en QGIS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4403"/>
        <source>Only if preview in Layers</source>
        <translation>Solo con vista previa</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="153"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;Download (from &lt;/span&gt;&lt;a href=&quot;http://aws.amazon.com/public-data-sets/landsat&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;Amazon Web Services&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;, &lt;/span&gt;&lt;a href=&quot;https://earthengine.google.com/datasets&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;Google Earth Engine&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;, &lt;/span&gt;&lt;a href=&quot;http://earthexplorer.usgs.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;USGS  EarthExplorer&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;Descarga (desde &lt;/span&gt;&lt;a href=&quot;http://aws.amazon.com/public-data-sets/landsat&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;Amazon Web Services&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;, &lt;/span&gt;&lt;a href=&quot;https://earthengine.google.com/datasets&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;Google Earth Engine&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;, &lt;/span&gt;&lt;a href=&quot;http://earthexplorer.usgs.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;USGS  EarthExplorer&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15978"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Run&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Ejecutar&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17154"/>
        <source>Import library</source>
        <translation>Importar librería</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4478"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export download links to a text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exporta los enlaces de descarga a un archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3620"/>
        <source> Search area</source>
        <translation>Area de búsqueda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9488"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set area in the map&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer área en el mapa&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9409"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lower right X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inferior derecha X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9439"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lower right Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inferior derecha Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9419"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Upper left X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Superior izquierda X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9429"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Upper left Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Superior izquierda Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3703"/>
        <source>LR X (Lon)</source>
        <translation>LR X (Lon)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3716"/>
        <source>UL Y (Lat)</source>
        <translation>UL Y (Lat)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3729"/>
        <source>UL X (Lon)</source>
        <translation>UL X (Lon)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3742"/>
        <source>LR Y (Lat)</source>
        <translation>LR Y (Lat)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9547"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Show / hide area&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mostrar / ocultar área&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9550"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3818"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Find images&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Encontrar imágenes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3838"/>
        <source>Find</source>
        <translation>Encontrar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3928"/>
        <source>yyyy-MM-dd</source>
        <translation>yyyy-MM-dd</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3884"/>
        <source>Max cloud cover (%)</source>
        <translation>Máx. nubosidad (%)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2907"/>
        <source>Satellites</source>
        <translation>Satélites</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3941"/>
        <source>to</source>
        <translation>hasta</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3954"/>
        <source>Date from</source>
        <translation>Fecha desde</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2977"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a satellite&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un satélite&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1853"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximum cloud cover percentage&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Máximo porcentaje de cobertura de nubes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4021"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt; Search&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt; Búsqueda&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4067"/>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4089"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter images&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrar imágenes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="797"/>
        <source>Landsat images</source>
        <translation>Imágenes Landsat</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15665"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Suprimir fila&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16156"/>
        <source>Plot</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4205"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display preview of highlighted images in map&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Muestra en el mapa una vista previa de las imágenes seleccionadas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16748"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Reset&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Reiniciar&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4269"/>
        <source> Image list</source>
        <translation> Listado de imágenes</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4298"/>
        <source>ImageID</source>
        <translation>ImagenID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4303"/>
        <source>AcquisitionDate</source>
        <translation>FechaDeAdquisición</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4308"/>
        <source>CloudCover</source>
        <translation>Nubosidad</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="938"/>
        <source>Path</source>
        <translation>Path</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="943"/>
        <source>Row</source>
        <translation>Row</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4323"/>
        <source>min_lat</source>
        <translation>lat_min</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4328"/>
        <source>min_lon</source>
        <translation>lon_min</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4333"/>
        <source>max_lat</source>
        <translation>lat_max</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4338"/>
        <source>max_lon</source>
        <translation>lon_max</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="968"/>
        <source>USGScollection</source>
        <translation>coleccionUSDS</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4348"/>
        <source>Preview</source>
        <translation>VistaPrevia</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4353"/>
        <source>collection</source>
        <translation>colección</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2180"/>
        <source>Download options</source>
        <translation>Opciones de Desacarga</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2301"/>
        <source>Band 6</source>
        <translation>Banda 6</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2281"/>
        <source>Band 4</source>
        <translation>Banda 4</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2351"/>
        <source>Band 10</source>
        <translation>Banda 10</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2205"/>
        <source>Band 1</source>
        <translation>Banda 1</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2271"/>
        <source>Band 3</source>
        <translation>Banda 3</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2341"/>
        <source>Band 9</source>
        <translation>Banda 9</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2311"/>
        <source>Band 7</source>
        <translation>Banda 7</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1095"/>
        <source>Band QA</source>
        <translation>Banda QA</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2261"/>
        <source>Band 2</source>
        <translation>Banda 2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1115"/>
        <source>Band 8 (Panchromatic)</source>
        <translation>Banda 8 (Pancromática)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2361"/>
        <source>Band 11</source>
        <translation>Banda 11</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2291"/>
        <source>Band 5</source>
        <translation>Banda 5</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15383"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Select all&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Seleccionar todas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1184"/>
        <source> Landsat 8 bands</source>
        <translation>Bandas Landsat 8</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3530"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, remember user name and password locally in QGIS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, recuerda el nombre de usuario y la contraseña internamente en QGIS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3533"/>
        <source>remember</source>
        <translation>recordar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3543"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Password&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Contraseña&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3550"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1244"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Login &lt;a href=&quot;https://ers.cr.usgs.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;https://ers.cr.usgs.gov&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Acceso &lt;a href=&quot;https://ers.cr.usgs.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;https://ers.cr.usgs.gov&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3586"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;User name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usuario&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3593"/>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1278"/>
        <source>Sentinel-2 download </source>
        <translation>Sentinel-2 descarga</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1459"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Login Sentinels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Acceso a Sentinels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4343"/>
        <source>Service</source>
        <translation>Servicio</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1607"/>
        <source> Search</source>
        <translation> Buscar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1949"/>
        <source>Sentinel images</source>
        <translation>Imágenes Sentinel</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2028"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display overview of highlighted images in map&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Muestra en el mapa un resumen de las imágenes seleccionadas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2101"/>
        <source>ImageName</source>
        <translation>NombreDeImagen</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2106"/>
        <source>Granule</source>
        <translation>Gránulo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2116"/>
        <source>Zone</source>
        <translation>Zona</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2146"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2156"/>
        <source>GranulePreview</source>
        <translation>VistaPreviaGránulo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2371"/>
        <source>Band 12</source>
        <translation>Banda 12</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2321"/>
        <source>Band 8</source>
        <translation>Banda 8</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2331"/>
        <source>Band 8A</source>
        <translation>Banda 8A</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2254"/>
        <source> Sentinel-2 bands</source>
        <translation>Bandas de Sentinel-2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2443"/>
        <source> Download</source>
        <translation>Descarga</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2532"/>
        <source>ASTER download</source>
        <translation>ASTER descarga</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3573"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Login &lt;a href=&quot;https://urs.earthdata.nasa.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;https://urs.earthdata.nasa.gov&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Acceso &lt;a href=&quot;https://urs.earthdata.nasa.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;https://urs.earthdata.nasa.gov&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3983"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Maximum cloud cover percentage&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Máximo porcentaje de nubosidad&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3185"/>
        <source>ASTER images</source>
        <translation>Imágenes ASTER</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4313"/>
        <source>ImageDisplayID</source>
        <translation>ImageDisplayID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4318"/>
        <source>DayNightFlag</source>
        <translation>EtiquetaDíaNoche</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4429"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;Download (from &lt;/span&gt;&lt;a href=&quot;https://lpdaac.usgs.gov/data_access/data_pool&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;NASA EOSDIS Land Processes DAAC&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;Descarga (desde &lt;/span&gt;&lt;a href=&quot;https://lpdaac.usgs.gov/data_access/data_pool&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;NASA EOSDIS Land Processes DAAC&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4515"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4535"/>
        <source>Multiple ROI creation</source>
        <translation>Creación de ROI múltiples</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4561"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Minimum distance between points&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Distancia mínima entre puntos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4598"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Size of a grid cell within points are created randomly&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Tamaño de la cuadrícula en la que se crearán los puntos aleatorios&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4633"/>
        <source>Create random points</source>
        <translation>Crear puntos aleatorios</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4653"/>
        <source>Create points</source>
        <translation>Crear puntos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4666"/>
        <source>Number of points</source>
        <translation>Número de puntos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4694"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Number of points created randomly&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Número de puntos creados aleatoriamente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4713"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create points&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crear puntos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4733"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create random points with a minimum distance&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crear puntos aleatorios con una distancia mínima&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4736"/>
        <source>min distance</source>
        <translation>distancia min</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4743"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create random points inside each cell of a grid with this size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crear puntos aleatorios dentro de cada celda en una cuadrícula con este tamaño&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4746"/>
        <source>inside grid</source>
        <translation>dentro de la cuadrícula</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4786"/>
        <source> Point coordinates and ROI definition</source>
        <translation> Coordenadas de los Puntos y definición de ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4806"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4811"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6446"/>
        <source>MC ID</source>
        <translation>MC ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6451"/>
        <source>MC Info</source>
        <translation>MC Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6456"/>
        <source>C ID</source>
        <translation>C ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6461"/>
        <source>C Info</source>
        <translation>C Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4836"/>
        <source>Min</source>
        <translation>Min</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4841"/>
        <source>Max</source>
        <translation>Max</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4846"/>
        <source>Dist</source>
        <translation>Dist</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4851"/>
        <source>Rapid ROI band</source>
        <translation>Banda para ROI rápido</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14968"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Agregar fila&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4922"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Export point list to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Exportar la lista de puntos a un archovo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4958"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Import point list from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Importar una lista de puntos desde un archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add ROI spectral signatures to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agrega las firmas espectrales de los ROI al listado de firmas espectrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5401"/>
        <source>Calculate sig.</source>
        <translation>Calcular firm.</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16073"/>
        <source> Run</source>
        <translation> Ejecutar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5084"/>
        <source>Import signatures</source>
        <translation>Importar firmas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5102"/>
        <source>Import library file</source>
        <translation>Importar archivo de librerías</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5122"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a file: SCP file (*.scp) ; USGS library (*.asc) ; ASTER library (*.txt) ; CSV (*.csv)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un archivo: archivo SCP (*.scp) ; librería USGS (*.asc) ; librería ASTER (*.txt) ; CSV (*.csv)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15363"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Open a file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Abrir archivo&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5176"/>
        <source>Import shapefile</source>
        <translation>Importar archivo shape</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9016"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open a file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abre un archivo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a shapefile (*.shp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un archivo shape (*.shp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5289"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a reference shapefile&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona una referencia al archivo shape&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16307"/>
        <source>C Info field</source>
        <translation>Campo C info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5312"/>
        <source> Shapefile fields</source>
        <translation> Campos del archivo shape</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16376"/>
        <source>C ID field</source>
        <translation>Campo C ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16399"/>
        <source>MC ID field</source>
        <translation>Campo MC ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16412"/>
        <source>MC Info field</source>
        <translation>Campo MC Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5378"/>
        <source>  Import shapefile</source>
        <translation> Importar shape</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5398"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add ROI spectral signature to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agregar las firmas espectrales del ROI a la lista de firmas espectrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5411"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import shapefile&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar archivo shape&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5464"/>
        <source>Download USGS Spectral Library</source>
        <translation>Descarga Librería Espectral de USGS</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5507"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a chapter&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un capítulo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5523"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a library&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona una librería&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5558"/>
        <source>Import spectral library</source>
        <translation>Importar una librería espectral</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5568"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import spectral library&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar una librería espectral&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5596"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5616"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;USGS Spectral Library downloaded from &lt;a href=&quot;http://speclab.cr.usgs.gov/spectral-lib.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://speclab.cr.usgs.gov/spectral-lib.html&lt;/span&gt;&lt;/a&gt;.&lt;br/&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Reference&lt;/span&gt;: R. N. Clark, G. A. Swayze, R. Wise, K. E. Livo, T. M. Hoefen, R. F. Kokaly, and S. J. Sutley, 2007, USGS Digital Spectral Library splib06a, U.S. Geological Survey, Data Series 231.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Librería Espectral USGS descargada desde &lt;a href=&quot;http://speclab.cr.usgs.gov/spectral-lib.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://speclab.cr.usgs.gov/spectral-lib.html&lt;/span&gt;&lt;/a&gt;.&lt;br/&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Referencia&lt;/span&gt;: R. N. Clark, G. A. Swayze, R. Wise, K. E. Livo, T. M. Hoefen, R. F. Kokaly, and S. J. Sutley, 2007, USGS Digital Spectral Library splib06a, U.S. Geological Survey, Data Series 231.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5645"/>
        <source> Library Description (requires internet connection)</source>
        <translation> Descripción de la Librería ( riquiere conexión a Internet)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5670"/>
        <source>Export signatures</source>
        <translation>Exportar librerías</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5748"/>
        <source>Export </source>
        <translation>Exportar </translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5771"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export as CSV file (.csv)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar como archivo CSV (.csv)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5681"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export as SCP file (*.scp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar como archivo SCP (*.scp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5778"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Export highlighted spectral signatures&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Exportar las firmas espectrales seleccionadas&lt;/p&gt;&lt;/body&gt;&lt;/head&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5709"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory where highlighted spectral signatures are saved as .csv&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el directorio donde las firmas espectrales seleccionadas serán guardadas como .csv&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5819"/>
        <source>Algorithm band weight</source>
        <translation>Algoritmo peso de banda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5852"/>
        <source>Band number</source>
        <translation>Número de banda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15522"/>
        <source>Band name</source>
        <translation>Nombre de banda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5862"/>
        <source>Weight</source>
        <translation>Peso</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5888"/>
        <source>Band weight</source>
        <translation>Peso de banda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6116"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Reset&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Restaurar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6321"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Asignar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5995"/>
        <source>Set weight</source>
        <translation>Asignar peso</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6305"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asignar un valor&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6053"/>
        <source>Automatic  weight</source>
        <translation>Peso  automático</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6216"/>
        <source>Signature threshold</source>
        <translation>Umbral de firma</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6180"/>
        <source>MD Threshold</source>
        <translation>Umbral MD</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6185"/>
        <source>ML Threshold</source>
        <translation>Umbral ML</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6190"/>
        <source>SAM Threshold</source>
        <translation>Umbral SAM</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6240"/>
        <source>Set threshold = σ *</source>
        <translation>Establecer umbral = σ *</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6624"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a value that will be multiplied by standard deviation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer el valor que será multiplicado por la esviación estándar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6640"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold σ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer umbral automáticamente σ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6295"/>
        <source>Set threshold</source>
        <translation>Establecer umbral</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6828"/>
        <source>Automatic  thresholds</source>
        <translation>Umbrales  Automáticos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6413"/>
        <source>LCS threshold</source>
        <translation>Umbral LCS</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6466"/>
        <source>Color [overlap MC_ID-C_ID]</source>
        <translation>Color [superponer MC_ID-C_ID]</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6492"/>
        <source>LC Signature threshold</source>
        <translation>Umbral de Cobertura del Suelo - LC Signature</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6506"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add highlighted signatures to spectral signature plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Agregar las firmas seleccionadas al gráfico de firmas espectrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6551"/>
        <source>Min Max</source>
        <translation>Min Max</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6561"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold Min Max&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer umbral Min Max automáticamente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6608"/>
        <source>σ *</source>
        <translation>σ *</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6691"/>
        <source>From pixel</source>
        <translation>Desde pixel</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6701"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activate pointer for setting thresholds from pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activar el puntero para establecer umbrales desde pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6723"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is extended to include pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, el umbral de firma se extiende para incluir la firma del pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6740"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is reduced to exclude pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si se selecciona, el umbral de firma se reduce para excluir la firma de pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6772"/>
        <source>From ROI</source>
        <translation>Desde ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6782"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set thresholds from temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer umbrales desde el ROI temporal&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6873"/>
        <source>RGB list</source>
        <translation>Lista RGB</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6900"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sort RGB automatically&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ordena automáticamente combinaciones RGB&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6923"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted RGB down&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mueve la combinación RGB seleccionada hacia abajo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6946"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted RGB up&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mueve la combinación RGB seleccionada hacia arriba&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6996"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export RGB list to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar la lista RGB a un archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7019"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import RGB list from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar lista RGB desde archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7131"/>
        <source>RGB</source>
        <translation>RGB</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7165"/>
        <source>Automatic RGB</source>
        <translation>RGB Automático</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7193"/>
        <source>Band combinations</source>
        <translation>Combinaciones de bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7203"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add all combinations of bands&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agregar todas la combinaciones de bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7252"/>
        <source>Preprocessing</source>
        <translation>Preprocesamiento</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7274"/>
        <source>Landsat</source>
        <translation>Landsat</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7304"/>
        <source>Directory containing Landsat bands</source>
        <translation>Directorio conteniendo bandas Landsat</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7336"/>
        <source> Landsat conversion to TOA reflectance and brightness temperature</source>
        <translation> Conversión a reflectancia TOA y Temperatura de Brillo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8548"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable calculation of temperature in Celsius from thermal band&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activa/Desactiva el cálculo de la temperatura en grados Celsius para la banda térmica&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8551"/>
        <source> Brightness temperature in Celsius</source>
        <translation> Temperatura de brillo en Celsius</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8471"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the DOS1 atmospheric correction (thermal band is not corrected)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activa/Desactiva la corrección atmosférica DOS1 (no se corrige la banda térmica)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8474"/>
        <source> Apply DOS1 atmospheric correction</source>
        <translation> Aplicar la corrección atmosférica DOS1</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9041"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;No data value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valor para SinDatos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9057"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ignore the NoData value in DOS1 calculation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ignora el valor SinDatos en el cálculo DOS1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9060"/>
        <source>Use NoData value (image has black border)</source>
        <translation>Usar valor SinDatos (la imagen tiene borde negro)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7440"/>
        <source>Select MTL file (if not in Landsat directory)</source>
        <translation>Seleccionar archivo MTL (si no se encuentra en el directorio Landsat)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17018"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p  &gt;Select a directory&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p  &gt;Selecciona un directorio&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7501"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Perform pan-sharpening (Brovey Transform)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Realizar el pan-sharpening (Transformación de Brovey)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7504"/>
        <source>Perform pansharpening (Landsat 7 or 8)</source>
        <translation>Realizar pansharpening (Landsat 7 u 8)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8966"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create the Band set automatically and use the checked Band set tools&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crea el conjunto de bandas automáticamente y utiliza las herramientas seleccionadas en la pestaña Juego de Bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8969"/>
        <source>Create Band set and use Band set tools</source>
        <translation>Crear Juego de Bandas y utilizar sus herramientas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9105"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit metadata&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Editar metadatos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9115"/>
        <source>Band</source>
        <translation>Banda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7571"/>
        <source>RADIANCE_MULT</source>
        <translation>RADIANCE_MULT</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7576"/>
        <source>RADIANCE_ADD</source>
        <translation>RADIANCE_ADD</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7581"/>
        <source>REFLECTANCE_MULT</source>
        <translation>REFLECTANCE_MULT</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7586"/>
        <source>REFLECTANCE_ADD</source>
        <translation>REFLECTANCE_ADD</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7591"/>
        <source>RADIANCE_MAXIMUM</source>
        <translation>RADIANCE_MAXIMUM</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7596"/>
        <source>REFLECTANCE_MAXIMUM</source>
        <translation>REFLECTANCE_MAXIMUM</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7601"/>
        <source>K1_CONSTANT</source>
        <translation>K1_CONSTANT</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7606"/>
        <source>K2_CONSTANT</source>
        <translation>K2_CONSTANT</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7611"/>
        <source>LMAX</source>
        <translation>LMAX</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7616"/>
        <source>LMIN</source>
        <translation>LMIN</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7621"/>
        <source>QCALMAX</source>
        <translation>QCALMAX</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7626"/>
        <source>QCALMIN</source>
        <translation>QCALMIN</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8286"/>
        <source>Satellite</source>
        <translation>Satélite</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8727"/>
        <source>Sun elevation</source>
        <translation>Elevación del Sol</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9157"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DATE ACQUIRED&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fecha de adquisición (DATE ACQUIRED)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7738"/>
        <source>Date (YYYY-MM-DD)</source>
        <translation>Date (YYYY-MM-DD)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8675"/>
        <source>Earth sun distance</source>
        <translation>Distancia Tierra-Sol</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8737"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SUN ELEVATION&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Elevación del Sol (SUN ELEVATION)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8652"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Earth sun distance&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Distancia de la tierra al Sol&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9186"/>
        <source>Metadata</source>
        <translation>Metadatos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7817"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Satellite (e.g. LANDSAT8)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Satélite (Ej. LANDSAT8)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7899"/>
        <source>Sentinel-2</source>
        <translation>Sentinel-2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7929"/>
        <source>Directory containing Sentinel-2 bands</source>
        <translation>Directorio conteniendo bandas Sentinel-2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7991"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the DOS1 atmospheric correction&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activa/Desactiva la corrección atmosférica DOS1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8072"/>
        <source> Sentinel-2 conversion</source>
        <translation>Conversión de Sentinel-2</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8192"/>
        <source>Quantification value</source>
        <translation>Valor de Cuantificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8197"/>
        <source>Solar irradiance</source>
        <translation>Irradiancia solar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8263"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Satellite (e.g. Sentinel-2A)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Satélite (Ej. Sentinel-2A)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8384"/>
        <source>ASTER</source>
        <translation>ASTER</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8509"/>
        <source> ASTER conversion to TOA reflectance and brightness temperature</source>
        <translation>ASTER convertir a reflectancia TOA y a Temperatura de Brillo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8538"/>
        <source>Select file ASTER L1T (.hdf)</source>
        <translation>Seleccionar archivo ASTER L1T (.hdf)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9120"/>
        <source>UnitConversionCoeff</source>
        <translation>UnitConversionCoeff</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8608"/>
        <source>PixelSize</source>
        <translation>PixelSize</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8701"/>
        <source>Date (YYYYMMDD)</source>
        <translation>Date (YYYY-MM-DD)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8744"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Upper left (meters)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Superior izquierda (metros)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8767"/>
        <source>UTM zone</source>
        <translation>Zona UTM</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8777"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;UTM zone&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zona UTM&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8829"/>
        <source>UPPERLEFTM</source>
        <translation>SUPIZQUIERDAM</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9294"/>
        <source>Clip multiple rasters</source>
        <translation>Recortar múltiples rásters</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15340"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Refresh list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Recargar lista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10125"/>
        <source> Raster list</source>
        <translation>Lista Ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15475"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select Rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona Rásters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9452"/>
        <source>UL Y</source>
        <translation>UL Y</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9465"/>
        <source>LR X</source>
        <translation>LR X</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9478"/>
        <source>LR Y</source>
        <translation>LR Y</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9524"/>
        <source> Clip coordinates</source>
        <translation>Coordenadas de Corte</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9537"/>
        <source>UL X</source>
        <translation>UL X</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9567"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use shapefile boundaries for clipping rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar límites de archivo shape para cortar rásters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9570"/>
        <source>Use shapefile for clipping</source>
        <translation>Usar archivo shape para cortar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9583"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the shapefile for clipping&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar el archivo shape para cortar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9613"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use temporary ROI boundaries for clipping rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar límites de ROI temporal para cortar rásters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9616"/>
        <source>Use temporary ROI for clipping</source>
        <translation>Usar ROI temporal para cortar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9632"/>
        <source>NoData value</source>
        <translation>Valor SinDatos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15142"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;NoData value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valor SinDatos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9920"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Output name prefix&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Prefijo para el nombre de salida&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9673"/>
        <source>clip</source>
        <translation>clip</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9955"/>
        <source>Output name prefix</source>
        <translation>Prefijo para nombre de salida</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9811"/>
        <source>Split raster bands</source>
        <translation>Separar bandas ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9825"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the image to be split&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona la imagen a separar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9854"/>
        <source>Raster input</source>
        <translation>Ráster de entrada</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9883"/>
        <source>Select a multiband raster</source>
        <translation>Selecciona una ráster multibanda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9923"/>
        <source>split</source>
        <translation>split</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10235"/>
        <source>PCA</source>
        <translation>PCA</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11812"/>
        <source>Input</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, calculate this number of components only&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionada, solo calcula este número de componentes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10278"/>
        <source>Number of components</source>
        <translation>Número de componentes</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10285"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Number of components&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número de componentes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10311"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, NoData value will be ignored during the calculation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, los valores SinDatos serán ignorados durante el cálculo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11834"/>
        <source>Use NoData value</source>
        <translation>Usar valores SinDatos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10431"/>
        <source> Principal Components Analysis of Band set</source>
        <translation> Análisis de Componentes Principales de un Juego de bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12130"/>
        <source>Output</source>
        <translation>Salida</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10492"/>
        <source>Vector to raster</source>
        <translation>Vectorial a ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10522"/>
        <source>Select the vector</source>
        <translation>Selecciona el vectorial</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13166"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el vectorial&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the value field of the vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar el valor del campo del vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13126"/>
        <source>Use the value field of the vector</source>
        <translation>Usar el valor del campo del vector</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13139"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the value field&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar el campo con valores&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12959"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use constant value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar un valor constante&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12962"/>
        <source>Use constant value</source>
        <translation>Usar un valor constante</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12972"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valor&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10775"/>
        <source>Select the type of conversion</source>
        <translation>Selecciona el tipo de conversión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10791"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the type of conversion&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el tipo de conversión&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10703"/>
        <source>Select the reference raster</source>
        <translation>Selecciona el ráster de referencia</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10742"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the reference raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el ráster de referencia&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10841"/>
        <source>Postprocessing</source>
        <translation>Postprocesamiento</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10861"/>
        <source>Accuracy</source>
        <translation>Precisión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10918"/>
        <source>Select the classification to assess</source>
        <translation>Selecciona la clasificación a evaluar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12014"/>
        <source>Select the reference shapefile or raster</source>
        <translation>Selecciona el archivo shape o ráster de referencia</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10960"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the classification to assess&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona la clasificación para ser evaluada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11916"/>
        <source>Shapefile field</source>
        <translation>Campo de archivo shape</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11070"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the field of the classification code &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el campo con el código de la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12149"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Courier 10 Pitch&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Courier 10 Pitch&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11217"/>
        <source>Land cover change</source>
        <translation>Cambio de cobertura del suelo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11252"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;If enabled, pixels having the same values in both classifications will be reported; if not enabled, 0 value is set for unchanged pixels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Si se selecciona, los pixeles que tienen el mismo valor en ambas clasificaciones se reportarán; si está desactivado, se asigna el valor 0 para los pixeles sin cambios&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11255"/>
        <source>Report unchanged pixels</source>
        <translation>Reportar pixeles sin cambios</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11271"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the reference classification raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el ráster con la clasificación de referencia&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11294"/>
        <source>Select the new classification</source>
        <translation>Selecciona la nueva clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11326"/>
        <source>Select the reference classification</source>
        <translation>Selecciona la clasificación de referencia</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11342"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a new raster to be compared with the reference raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un nuevo ráster que será comparado con el ráster de referencia&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11528"/>
        <source>Classification report</source>
        <translation>Reporte de la clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12454"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the classification raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el ráster con la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13964"/>
        <source>Select the classification</source>
        <translation>Selecciona la clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11831"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, NoData value will be excluded from the report&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, los valores SinDatos será excluidos del reporte&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12177"/>
        <source>Classification to vector</source>
        <translation>Clasificación a vectorial</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12685"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the codes from Signature list table for vector symbology&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usa los códigos de la tabla del listado de Firmas para la simbología vectorial&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12688"/>
        <source>Use code from Signature list</source>
        <translation>Usar código del listado de Firmas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12704"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the code field&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el código del campo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12713"/>
        <source>C_ID</source>
        <translation>C_ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12708"/>
        <source>MC_ID</source>
        <translation>MC_ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12743"/>
        <source> Symbology</source>
        <translation> Simbología</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12408"/>
        <source>Reclassification</source>
        <translation>Reclasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12488"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate unique values&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcula valores únicos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12508"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable this for reclassification from C ID to MC ID; if checked, unique values are calculated from the Signature list, setting old value C ID and new value MC ID&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona esta casilla para la reclasificación de C ID a MC ID; si está seleccionada, se calculan valores únicos de la lista de Firmas, colocando los viejos valores de C ID y nuevos valores para MC ID&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12511"/>
        <source>calculate C ID to MC ID values</source>
        <translation>calcular valores de C ID a MC ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12534"/>
        <source>Calculate unique values</source>
        <translation>Calcular valores únicos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12566"/>
        <source> Values</source>
        <translation> Valores</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12590"/>
        <source>Old value</source>
        <translation>Valor antiguo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12595"/>
        <source>New value</source>
        <translation>Valor Nuevo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12825"/>
        <source>Edit raster</source>
        <translation>Editar ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12836"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Undo edit (only for ROI polygons)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Deshacer editar (solo para polígonos ROI)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12909"/>
        <source>Select the input raster</source>
        <translation>Selecciona el ráster de entrada</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12925"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the raster to edit&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona el ráster para ser editado&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13002"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use expression&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Usar una expresión&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13005"/>
        <source>Use expression</source>
        <translation>Usar expresión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13030"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter expression&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ingresa una expresión&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13033"/>
        <source>where(raster == 1, 2, raster)</source>
        <translation>where(raster == 1, 2, raster)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13112"/>
        <source> Edit raster values</source>
        <translation> Editar valores de un ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13150"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit values using a vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Editar los valores utilizando un vectorial&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13153"/>
        <source> Edit values using a vector</source>
        <translation> Editar valores usando vectorial</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit values using temporary ROIs&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Editar valores utilizando ROIs temporales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13203"/>
        <source> Edit values using ROI polygons</source>
        <translation> Editar valores usando polígonos ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13233"/>
        <source> Edit options</source>
        <translation> Opciones de Edición</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13249"/>
        <source>Classification sieve</source>
        <translation>Filtrado de la Clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13980"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona la clasificación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13402"/>
        <source>Size threshold</source>
        <translation>Tamaño de umbral</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13412"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Size threshold in pixels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño del umbral en pixeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14097"/>
        <source>Pixel connection</source>
        <translation>Conexión de pixeles</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14119"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pixel connection&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Conexión de pixeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14123"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14128"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13534"/>
        <source>Classification erosion</source>
        <translation>Erosión de la clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14036"/>
        <source>Size in pixels</source>
        <translation>Tamaño en pixeles</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14046"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Size in pixels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño en pixeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14156"/>
        <source>Class values</source>
        <translation>Valores de Clase</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14184"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter class values separated by , or -&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ingresa valores de Clases separados por , o -&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13883"/>
        <source>Classification dilation</source>
        <translation>Dilatación de la Clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14236"/>
        <source>Band calc</source>
        <translation>Calculadora de Bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15447"/>
        <source> Band list</source>
        <translation> Lista de Bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14285"/>
        <source>Expression</source>
        <translation>Expresión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inverse cosine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Coseno inverso&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14315"/>
        <source>acos</source>
        <translation>acos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14328"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seno&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14331"/>
        <source>sin</source>
        <translation>sen</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14344"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inverse sine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seno inverso&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14347"/>
        <source>asin</source>
        <translation>asen</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14360"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cosine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Coseno&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14363"/>
        <source>cos</source>
        <translation>cos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14376"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tangent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tangente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14379"/>
        <source>tan</source>
        <translation>tan</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14392"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inverse tangent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tangente inversa&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14395"/>
        <source>atan</source>
        <translation>atan</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14412"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;NoData value of raster (e.g.  nodata(&amp;quot;raster1&amp;quot;) )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Valor SinDatos de un ráster (Ej. nodata(&amp;quot;raster1&amp;quot;) )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14415"/>
        <source>nodata</source>
        <translation>SinDatos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14430"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Conditional where function&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Función condicional where&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14433"/>
        <source>where</source>
        <translation>donde</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14446"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exponential&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exponencial&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14449"/>
        <source>exp</source>
        <translation>exp</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14466"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Not equals&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;No iguales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14469"/>
        <source>!=</source>
        <translation>!=</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14482"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Equals&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Iguales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14485"/>
        <source>==</source>
        <translation>==</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14504"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Multiplication&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Multiplicación&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14507"/>
        <source>*</source>
        <translation>*</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14520"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Power&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Potencia&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14523"/>
        <source>^</source>
        <translation>^</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14536"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minus&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Menos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14539"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14552"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Plus&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Más&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14555"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14568"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Division&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;División&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14571"/>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14584"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Close parenthesis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cerrar paréntesis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14587"/>
        <source>)</source>
        <translation>)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14600"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Square root&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Raíz cuadrada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14603"/>
        <source>√</source>
        <translation>√</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14616"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open parenthesis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abrir paréntesis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14619"/>
        <source>(</source>
        <translation>(</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14632"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14635"/>
        <source>π</source>
        <translation>π</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14648"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Natural logarithm&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Logaritmo Natural&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14651"/>
        <source>ln</source>
        <translation>ln</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14664"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Greater than&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mayor que&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14667"/>
        <source>&gt;</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14680"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Less than&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Menor que&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14683"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14745"/>
        <source>Index calculation</source>
        <translation>Cálculo de índice</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14702"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an index&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un índice&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14792"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter an expression (e.g. &amp;quot;raster1&amp;quot; + &amp;quot;raster2&amp;quot; )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Escribe una expresión (Ej. &amp;quot;raster1&amp;quot; + &amp;quot;raster2&amp;quot; )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14813"/>
        <source>Decision rules</source>
        <translation>Reglas de decisión</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14826"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter one or more rules separated by semicolon (e.g. &amp;quot;raster1&amp;quot; &amp;gt; 0; &amp;quot;raster2&amp;quot; &amp;gt; 0 )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ingresa una o más reglas separadas por punto y coma (Ej. &amp;quot;raster1&amp;quot; &amp;gt; 0; &amp;quot;raster2&amp;quot; &amp;gt; 0 )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14833"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14838"/>
        <source>Rule</source>
        <translation>Regla</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted rule up&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mueve la regla seleccionada hacia arriba&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14909"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import rules from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar reglas desde archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14991"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export rules to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar reglas hacia archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15027"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted rule down&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mueve la regla seleccionada hacia abajo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15070"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Band list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lista de bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15098"/>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15155"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, pixels equal to NoData value will be excluded from the output raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionada, los pixeles iguales al valor SinDatos serán excluidos del ráster de salida&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15158"/>
        <source>Set NoData value</source>
        <translation>Establecer valor SinDatos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15165"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the extent of raster ouput equals the extent of selected raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionada, la extensión del ráster de salida será igual que la del ráster seleccionado&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15168"/>
        <source>Same as</source>
        <translation>Igual que</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15181"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona un ráster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15188"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the extent of raster ouput equals the intersection of input rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionada, la extensión del ráster de salida será igual a la intersección con el ráster de entrada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15191"/>
        <source>Intersection</source>
        <translation>Intersección</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15242"/>
        <source>Extent:</source>
        <translation>Extensión:</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15291"/>
        <source>Output raster</source>
        <translation>Ráster de salida</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15330"/>
        <source>Band set</source>
        <translation>Juego de bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15406"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add band to Band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agregar bandas al Juego de Bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15494"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Juego de bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15527"/>
        <source>Center wavelength</source>
        <translation>Centro de longitud de onda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15532"/>
        <source>Multiplicative Factor</source>
        <translation>Factor Multiplicativo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15537"/>
        <source>Additive Factor</source>
        <translation>Factor Aditivo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15563"/>
        <source> Band set definition</source>
        <translation> Definición del Juego de bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15592"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sort bands by name (priority to ending number)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ordenar bandas por nombre (teniendo prioridad el número final)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15615"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted band down&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mueve la banda seleccionada hacia abajo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15638"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted band up&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mueve la banda seleccionada hacia arriba&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15701"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export band set to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar el juego de bandas a un archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15747"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import band set from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar un juego de bandas desde un archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15794"/>
        <source> Quick wavelength settings</source>
        <translation> Configuración rápida de longitud de onda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15804"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a configuration for setting band center wavelengths&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona una configuración para establecer el centro de la longitud de onda&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15829"/>
        <source>Wavelength unit</source>
        <translation>Unidad de longitud de onda</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15839"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wavelength unit&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Unidad de longitud de onda&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15852"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create a virtual raster of band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crear un ráster virtual del Juego de Bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15855"/>
        <source>Create virtual raster of band set</source>
        <translation>Crear ráster virtual de Juego de Bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15862"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate expression in Band calc&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcular expresión ingresada en Calculadora de Bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15865"/>
        <source>Band calc expressions</source>
        <translation>Expresiones en Calculadora de Bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15872"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create a .tif raster stacking the bands of the band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Crea un ráster .tif multibanda apilando las bandas del Juego de Bandas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15875"/>
        <source>Create raster of band set (stack bands)</source>
        <translation>Crear ráster de Juego de bandas (bandas apiladas)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15882"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Build band overviews (external pyramids) for faster visualization&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Construye Vistas Generales (pirámides externas) para la visualización del ráster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15885"/>
        <source>Build band overviews</source>
        <translation>Construir Vistas Generales</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15908"/>
        <source> Band set tools</source>
        <translation> Herramientas para Juego de bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16103"/>
        <source>Batch</source>
        <translation>En Lotes</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16238"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter a batch function&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ingrese un lote de funciones&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16022"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a function&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona una función&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16045"/>
        <source>Functions</source>
        <translation>Funciones</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import batch from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Importar proceso en lotes desde archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16150"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export batch to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar proceso en lotes a un archivo de texto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16275"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16293"/>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16314"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Class information field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asignar el nombre campo con información de la Clase&lt;/p&gt;&lt;p&gt;[máx 10 caracteres]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16340"/>
        <source> Field names of training input</source>
        <translation>Nombres de campo del Entrenamiento de Entrada</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16350"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Class ID field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asignar el nombre de campo Class ID&lt;/p&gt;&lt;p&gt;[máx 10 caracteres]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16360"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Macroclass ID field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asignar el nombre de campo Macroclass ID&lt;/p&gt;&lt;p&gt;[máx 10 caracteres]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16383"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Macroclass information field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asignar el nombre campo con información de la Macroclase&lt;/p&gt;&lt;p&gt;[máx 10 caracteres]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16462"/>
        <source> ROI style</source>
        <translation>Estilo del ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16474"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select temporary ROI color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Seleccionar color del ROI temporal&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16496"/>
        <source>ROI color</source>
        <translation>Color del ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16518"/>
        <source>Transparency</source>
        <translation>Transparencia</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16525"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Change temporary ROI transparency&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cambia la transparencia del ROI temporal&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16595"/>
        <source> Variable name</source>
        <translation>Nombre de variable</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16611"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Variable name for expressions&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nombre de variable para expresiones&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16614"/>
        <source>raster</source>
        <translation>ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16640"/>
        <source> Variable name for expressions (tab Reclassification and Edit raster)</source>
        <translation>Nombre de variable para expresiones (pestaña Reclasificación y Editar ráster)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16693"/>
        <source>Group name</source>
        <translation>Nombre de grupo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16709"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Group name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nombre de grupo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16712"/>
        <source>Class_temp_group</source>
        <translation>Class_temp_group</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16738"/>
        <source> Temporary group name</source>
        <translation>Nombre temporal de grupo</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16791"/>
        <source> Dock</source>
        <translation>Panel</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16801"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, news about the SCP are downloaded on startup and displayed in Dock&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, las noticias sobre SCP son descargadas y mostradas en el panel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16804"/>
        <source>Download news on startup</source>
        <translation>Descarga noticias al inicio</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16840"/>
        <source>Processing</source>
        <translation>Procesado</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16848"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the sound when the process is finished&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activar/Desactivar el sonido cuando el proceso termina&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16851"/>
        <source>Play sound when finished</source>
        <translation>Reproducir sonido cuando termina</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16864"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, create virtual rasters for certain temporary files&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, crea rásters virtuales para ciertos archivos temporales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16867"/>
        <source>Use virtual raster for temp files</source>
        <translation>Usar ráster virtual para archivos temporales</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16890"/>
        <source>Classification process</source>
        <translation>Procesos para la Clasificación</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16897"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, a lossless compression is applied to rasters in order to save disk space&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, se aplica la compresión sin pérdidas a los rásters con el fin de ahorrar espacio en disco&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16900"/>
        <source>Raster compression</source>
        <translation>Compresión Ráster</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16930"/>
        <source> RAM</source>
        <translation> RAM</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16957"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set available RAM for processes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Asignar RAM disponible para los procesos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16982"/>
        <source>Available RAM (MB)</source>
        <translation>RAM disponible (MB)</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="16995"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Reset to default temporary directory&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Restaurar al directorio temporal por defecto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17057"/>
        <source>Temporary directory</source>
        <translation>Directorio temporal</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17101"/>
        <source>Debug</source>
        <translation>Depurar</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the Log of events&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activar/Desactivar Log de eventos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17112"/>
        <source>Record events in a Log file</source>
        <translation>Guardar eventos en un archivo Log</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17125"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export the Log file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exportar el archivo Log&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17148"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear the Log file content&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vaciar el contenido del archivo Log&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17187"/>
        <source> Log file</source>
        <translation>Archivo Log</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17198"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Test dependencies&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Comprobar dependencias&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17218"/>
        <source>Test dependencies</source>
        <translation>Verificar dependencias</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17257"/>
        <source> Test</source>
        <translation>Prueba</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17297"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="17367"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Developed by &lt;/span&gt;&lt;a href=&quot;http://www.researchgate.net/profile/Luca_Congedo&quot;&gt;&lt;span style=&quot; font-size:10pt; text-decoration: underline; color:#0057ae;&quot;&gt;Luca Congedo&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; (ing.congedoluca@gmail.com), the &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Semi-Automatic Classification Plugin&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; (SCP) is a free open source plugin for QGIS that allows for the semi-automatic classification(also supervised classification) of remote sensing images.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;It provides several tools for the download of free images, the preprocessing, the postprocessing, and the raster calculation.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For more information and tutorials visit the official site &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;From GIS to Remote Sensing.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/plugins/semiautomaticclassificationplugin/icons/fromGIStoRS.png&quot; /&gt;&lt;a href=&quot;https://fromgistors.blogspot.com/p/semi-automatic-classification-plugin.html?spref=sacp&quot;&gt;&lt;span style=&quot; font-size:14pt; text-decoration: underline; color:#0000ff;&quot;&gt;From GIS to Remote Sensing&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;a href=&quot;https://www.facebook.com/groups/SemiAutomaticClassificationPlugin&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;Semi-Automatic Classification Plugin group on Facebook&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://plus.google.com/communities/107833394986612468374&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;Semi-Automatic Classification Plugin community on Google+&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;This plugin requires the installation of GDAL, OGR, Numpy, SciPy, and Matplotlib (already bundled with QGIS).&lt;/span&gt;&lt;/p&gt;
&lt;hr /&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;&lt;br /&gt;The Semi-Automatic Classification Plugin is developed by Luca Congedo.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Translators:&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Language: Author&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Semi-Automatic Classification Plugin is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 3 of the License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Semi-Automatic Classification Plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with Semi-Automatic Classification Plugin. If not, see &amp;lt;&lt;/span&gt;&lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.gnu.org/licenses/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;&amp;gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15311"/>
        <source>Align</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4102"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4124"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximum number of results (images)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11794"/>
        <source>Cross classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12030"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the reference shapefile or raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11932"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the shapefile field&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2381"/>
        <source>Ancillary data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3522"/>
        <source>MODIS download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4172"/>
        <source>MODIS images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8914"/>
        <source>MODIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8944"/>
        <source> MODIS conversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9006"/>
        <source>Select file MODIS (.hdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9209"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9085"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Reproject bands to WGS 84&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9088"/>
        <source>Reproject to WGS 84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3897"/>
        <source>Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3964"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a product&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5761"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export as shapefile (*.shp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10051"/>
        <source>Stack raster bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8101"/>
        <source>Select metadata file (MTD_MSIL1C)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectralSignaturePlot</name>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="20"/>
        <source>SCP: Spectral Signature Plot</source>
        <translation>SCP: Gráfico de Firma Espectral</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="70"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="75"/>
        <source>MC ID</source>
        <translation>MC ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="80"/>
        <source>MC Info</source>
        <translation>MC Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="85"/>
        <source>C ID</source>
        <translation>C ID</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="90"/>
        <source>C Info</source>
        <translation>C Info</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="95"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="124"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activate pointer for setting thresholds from pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activar el puntero para establecer umbrales desde pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="160"/>
        <source>From pixel</source>
        <translation>Desde pixel</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="178"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is reduced to exclude pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si se selecciona, el umbral de firma se reduce para excluir la firma de pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="198"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is extended to include pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si está seleccionado, el umbral de firma se extiende para incluir la firma del pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="235"/>
        <source>From ROI</source>
        <translation>Desde ROI</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set thresholds from temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer umbrales desde el ROI temporal&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="293"/>
        <source>Automatic  thresholds</source>
        <translation>Umbrales  Automáticos</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="307"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold Min Max&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer umbral Min Max automáticamente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="343"/>
        <source>Min Max</source>
        <translation>Min Max</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="365"/>
        <source>σ *</source>
        <translation>σ *</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="381"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a value that will be multiplied by standard deviation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer el valor que será multiplicado por la esviación estándar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="397"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold σ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer umbral automáticamente σ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="420"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Undo thresholds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Deshacer umbrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="426"/>
        <source>Import library</source>
        <translation>Importar librería</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="449"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Eliminar fila&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="592"/>
        <source>Plot</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="472"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add highlighted spectral signatures to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Agregar las firmas espectrales seleccionadas a la lista de firmas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="495"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate spectral distances&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calcula las distancias espectrales&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="544"/>
        <source> Signature list</source>
        <translation>Lista de firmas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="841"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Plot the value range (standard deviation or defined minimum and maximum) for each signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Grafica el rango de valores (desviación estándar o el mínimo máximo definido) para cada firma&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="623"/>
        <source>Band lines</source>
        <translation>Líneas de bandas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="649"/>
        <source>Max characters</source>
        <translation>Caracteres Máx</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="668"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Text lenght of names in the spectral plot legend&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Largo del texto para los nombres en la leyenda del gráfico espectral&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="702"/>
        <source>x=0.000000 y=0.000000</source>
        <translation>x=0.000000 y=0.000000</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="724"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Change value range interactively in the plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cambiar interactivamente el rango de valores en el gráfico&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="744"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically fit the plot to data&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ajusta el gráfico a los datos automaticamente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="767"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save the plot to file (jpg, png, pdf)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Guarda el gráfico en un archivo (jpg, png, pdf)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="812"/>
        <source>Plot value range</source>
        <translation>Graficar rango de valores</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="844"/>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="865"/>
        <source>Signature details</source>
        <translation>Detalles de firmas</translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="891"/>
        <source>Spectral distances</source>
        <translation>Distancias espectrales</translation>
    </message>
</context>
<context>
    <name>semiautomaticclassificationplugin</name>
    <message>
        <location filename="semiautomaticclassificationplugin.py" line="1497"/>
        <source>Please, restart QGIS for executing the Semi-Automatic Classification Plugin</source>
        <translation>Por favor, reinicia QGIS para ejecutar el Semi-Automatic Classification Plugin</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="309"/>
        <source>Select a mask shapefile</source>
        <translation>Selecciona archivo shape de máscara</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="529"/>
        <source>Save classification output</source>
        <translation>Guardar los resultados de la clasificación</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="619"/>
        <source> conversion to vector. Please wait ...</source>
        <translation>convirtiendo a vectorial. Por favor espera ...</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="715"/>
        <source>Select a qml style</source>
        <translation>Selecciona un estilo qml</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="785"/>
        <source>Select a signature list file</source>
        <translation>Selecciona un archivo de lista de firma</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="799"/>
        <source>Select a SCP training input</source>
        <translation>Selecciona una Entrada de Entrenamiento SCP</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1188"/>
        <source>Export SCP training input</source>
        <translation>Exportar Entrada de Entrenamiento SCP</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1249"/>
        <source>Select a library file</source>
        <translation>Selecciona un archivo de librería</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1278"/>
        <source>Export the highlighted signatures to CSV library</source>
        <translation>Exportar las firmas seleccionadas a librería CSV</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1351"/>
        <source>Calculate signatures</source>
        <translation>Calcular firmas</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1351"/>
        <source>Calculate signatures for highlighted items?</source>
        <translation>¿Calcular firmas para los elementos seleccionados?</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1377"/>
        <source>Merge signatures</source>
        <translation>Combinar firmas</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1377"/>
        <source>Merge highlighted signatures?</source>
        <translation>¿Combinar firmas seleccionadas?</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="470"/>
        <source>Delete signatures</source>
        <translation>Eliminar firmas</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1498"/>
        <source>Are you sure you want to delete highlighted ROIs and signatures?</source>
        <translation>¿Estás seguro que quieres eliminar los ROIs y las firmas seleccionadas?</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2090"/>
        <source>Create SCP training input</source>
        <translation>Crear Entrenamiento de Entrada SCP</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2198"/>
        <source>Add required fds</source>
        <translation>Añadir los fondos requeridos</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2198"/>
        <source>It appears that the shapefile </source>
        <translation>Parece que el archivo shape</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2198"/>
        <source> is missing some fields that are required for the signature calculation. 
Do you want to add the required fields to this shapefile?</source>
        <translation>no se encuentran algunos campos que son requeridos para el cálculo de firmas.
¿Deseas agregar los campos requeridos a este archivo shape?</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2282"/>
        <source>Undo save ROI</source>
        <translation>Deshacer guardar ROI</translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2282"/>
        <source>Are you sure you want to delete the last saved ROI?</source>
        <translation>¿Estás seguro que quieres eliminar el último ROI guardado?</translation>
    </message>
    <message>
        <location filename="input.py" line="137"/>
        <source>Semi-Automatic Classification Plugin</source>
        <translation>Semi-Automatic Classification Plugin</translation>
    </message>
    <message>
        <location filename="input.py" line="141"/>
        <source>Zoom to input image extent</source>
        <translation>Zoom a la extensión de la imagen de entrada</translation>
    </message>
    <message>
        <location filename="input.py" line="143"/>
        <source>Show/hide the input image</source>
        <translation>Mostrar/Ocultar la imagen de entrada</translation>
    </message>
    <message>
        <location filename="input.py" line="149"/>
        <source>Select a RGB color composite</source>
        <translation>Selecciona una composición RGB</translation>
    </message>
    <message>
        <location filename="input.py" line="152"/>
        <source>Local cumulative cut stretch of band set</source>
        <translation>Cortar estiramiento local acumulativo del juego de bandas</translation>
    </message>
    <message>
        <location filename="input.py" line="154"/>
        <source>Local standard deviation stretch of band set</source>
        <translation>Desviación estándar del estiramiento local del juego de bandas</translation>
    </message>
    <message>
        <location filename="input.py" line="156"/>
        <source>Zoom to temporary ROI</source>
        <translation>Zoom al ROI temporal</translation>
    </message>
    <message>
        <location filename="input.py" line="158"/>
        <source>Show/hide the temporary ROI</source>
        <translation>Mostrar/Ocultar ROI temporal</translation>
    </message>
    <message>
        <location filename="input.py" line="160"/>
        <source>Create a ROI polygon</source>
        <translation>Crear un ROI de polígono</translation>
    </message>
    <message>
        <location filename="input.py" line="162"/>
        <source>Activate ROI pointer</source>
        <translation>Activar el puntero ROI</translation>
    </message>
    <message>
        <location filename="input.py" line="164"/>
        <source>Redo the ROI at the same point</source>
        <translation>Rehacer el ROI al mismo punto</translation>
    </message>
    <message>
        <location filename="input.py" line="167"/>
        <source> Dist</source>
        <translation>Dist</translation>
    </message>
    <message>
        <location filename="input.py" line="168"/>
        <source>Similarity of pixels (distance in radiometry unit)</source>
        <translation>Similitud de pixeles (distancia en unidad radiométrica)</translation>
    </message>
    <message>
        <location filename="input.py" line="170"/>
        <source> Min</source>
        <translation> Min</translation>
    </message>
    <message>
        <location filename="input.py" line="171"/>
        <source>Minimum area of ROI (in pixel unit)</source>
        <translation>Area mínima del ROI (en unidades de pixel)</translation>
    </message>
    <message>
        <location filename="input.py" line="173"/>
        <source> Max</source>
        <translation> Máx</translation>
    </message>
    <message>
        <location filename="input.py" line="174"/>
        <source>Side of a square which inscribes the ROI, defining the maximum width thereof (in pixel unit)</source>
        <translation>Lado de un cuadrado que inscribe al ROI, que define la anchura máxima de los mismos (en unidades de pixel)</translation>
    </message>
    <message>
        <location filename="input.py" line="176"/>
        <source>Zoom to the classification preview</source>
        <translation>Zoom a la clasificación preliminar</translation>
    </message>
    <message>
        <location filename="input.py" line="178"/>
        <source>Show/hide the classification preview</source>
        <translation>Muestra/Oculta la clasificación preliminar</translation>
    </message>
    <message>
        <location filename="input.py" line="180"/>
        <source>Activate classification preview pointer</source>
        <translation>Activa el puntero para clasificación preliminar</translation>
    </message>
    <message>
        <location filename="input.py" line="181"/>
        <source>Redo the classification preview at the same point</source>
        <translation>Rehacer la clasificación preliminar en el mismo puto</translation>
    </message>
    <message>
        <location filename="input.py" line="184"/>
        <source> T</source>
        <translation> T</translation>
    </message>
    <message>
        <location filename="input.py" line="185"/>
        <source>Set preview transparency</source>
        <translation>Establecer la transparencia de la vista preliminar</translation>
    </message>
    <message>
        <location filename="input.py" line="187"/>
        <source> S</source>
        <translation> S</translation>
    </message>
    <message>
        <location filename="input.py" line="188"/>
        <source>Set the preview size (in pixel unit)</source>
        <translation>Establecer el tamaño de la vista preliminar (en unidades de pixel)</translation>
    </message>
    <message>
        <location filename="input.py" line="189"/>
        <source>Remove temporary files</source>
        <translation>Eliminar archivos temporales</translation>
    </message>
    <message>
        <location filename="input.py" line="356"/>
        <source>Band set</source>
        <translation>Juego de bandas</translation>
    </message>
    <message>
        <location filename="input.py" line="358"/>
        <source>Download images</source>
        <translation>Descarga Imágenes</translation>
    </message>
    <message>
        <location filename="input.py" line="368"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="input.py" line="384"/>
        <source>Preprocessing</source>
        <translation>Preprocesamiento</translation>
    </message>
    <message>
        <location filename="input.py" line="404"/>
        <source>Postprocessing</source>
        <translation>Postprocesamiento</translation>
    </message>
    <message>
        <location filename="input.py" line="426"/>
        <source>Band calc</source>
        <translation>Calculadora de Bandas</translation>
    </message>
    <message>
        <location filename="input.py" line="428"/>
        <source>Spectral plot</source>
        <translation>Gráfico espectral</translation>
    </message>
    <message>
        <location filename="input.py" line="430"/>
        <source>Scatter plot</source>
        <translation>Gráfico de dispersión</translation>
    </message>
    <message>
        <location filename="input.py" line="432"/>
        <source>Batch</source>
        <translation>En Lotes</translation>
    </message>
    <message>
        <location filename="input.py" line="434"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="input.py" line="451"/>
        <source>User manual</source>
        <translation>Manual del Usuario</translation>
    </message>
    <message>
        <location filename="input.py" line="453"/>
        <source>Online help</source>
        <translation>Ayuda en línea</translation>
    </message>
    <message>
        <location filename="input.py" line="352"/>
        <source>SCP</source>
        <translation>SCP</translation>
    </message>
    <message>
        <location filename="messages.py" line="73"/>
        <source>Test results</source>
        <translation>Resultados de la prueba</translation>
    </message>
    <message>
        <location filename="messages.py" line="133"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="messages.py" line="76"/>
        <source>Default ROI style</source>
        <translation>Estilo predeterminado del ROI</translation>
    </message>
    <message>
        <location filename="messages.py" line="79"/>
        <source>No log file found</source>
        <translation>No se encuentra el archivo Log</translation>
    </message>
    <message>
        <location filename="messages.py" line="82"/>
        <source>Select a SCP training input; input is not loaded</source>
        <translation>Selecciona una Entrada de Entrenamiento SCP, la entrada no se ha cargado</translation>
    </message>
    <message>
        <location filename="messages.py" line="85"/>
        <source>Select a raster; raster is not loaded</source>
        <translation>Selecciona un ráster, no se ha cargado el ráster</translation>
    </message>
    <message>
        <location filename="messages.py" line="88"/>
        <source>Select a point inside the image area</source>
        <translation>Selecciona un punto dentro del área de la imagen</translation>
    </message>
    <message>
        <location filename="messages.py" line="91"/>
        <source>No file found</source>
        <translation>No se encuentra el archivo</translation>
    </message>
    <message>
        <location filename="messages.py" line="94"/>
        <source>Data projections do not match. Reproject data to the same projection</source>
        <translation>Las proyecciones de los datos no coinciden. Reproyecta los datos a la misma proyección</translation>
    </message>
    <message>
        <location filename="messages.py" line="97"/>
        <source>Maximum Likelihood threshold must be less than 100</source>
        <translation>El umbral de probabilidad máximo debe ser menor que 100</translation>
    </message>
    <message>
        <location filename="messages.py" line="100"/>
        <source>Spectral Angle Mapping threshold must be less than 90</source>
        <translation>El umbral para el Angulo Espectral de Mapeo debe ser menor que 90</translation>
    </message>
    <message>
        <location filename="messages.py" line="103"/>
        <source>Select a classification output</source>
        <translation>Selecciona una salida para la clasificación</translation>
    </message>
    <message>
        <location filename="splitTab.py" line="79"/>
        <source>Select a directory</source>
        <translation>Selecciona un directorio</translation>
    </message>
    <message>
        <location filename="messages.py" line="109"/>
        <source>Restart QGIS for the new settings</source>
        <translation>Reinicia QGIS para que la nueva configuración</translation>
    </message>
    <message>
        <location filename="messages.py" line="112"/>
        <source>At least 3 points are required</source>
        <translation>Se requieren al menos 3 puntos</translation>
    </message>
    <message>
        <location filename="messages.py" line="115"/>
        <source>Negative IDs are not allowed</source>
        <translation>No están permitidos los IDs negativos</translation>
    </message>
    <message>
        <location filename="messages.py" line="118"/>
        <source>Select at least one signature</source>
        <translation>Selecciona al menos una firma</translation>
    </message>
    <message>
        <location filename="messages.py" line="121"/>
        <source>SCP is recording the Log file</source>
        <translation>SCP está guardando el archivo Log</translation>
    </message>
    <message>
        <location filename="messages.py" line="124"/>
        <source>Signature list file (.slf) created</source>
        <translation>Se ha creado el archivo de listado de firmas (.slf)</translation>
    </message>
    <message>
        <location filename="messages.py" line="127"/>
        <source>No image found. Try with a larger area</source>
        <translation>No se encontró la imagen. Intenta con un área más grande</translation>
    </message>
    <message>
        <location filename="messages.py" line="130"/>
        <source>Create a ROI polygon or use a vector</source>
        <translation>Crea un polígono ROI o utiliza un vectorial</translation>
    </message>
    <message>
        <location filename="messages.py" line="133"/>
        <source>Define a search area</source>
        <translation>Define un área de búsqueda</translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="326"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="messages.py" line="137"/>
        <source>Classification failed.</source>
        <translation>La clasificación falló.</translation>
    </message>
    <message>
        <location filename="messages.py" line="158"/>
        <source>No metadata found inside the input directory (a .txt file whose name contains MTL)</source>
        <translation>No se encontró metadatos en el directorio de entrada (un archivo .txt cuyo nombre contiene MTL)</translation>
    </message>
    <message>
        <location filename="messages.py" line="161"/>
        <source>Raster not found</source>
        <translation>Ráster no encontrada</translation>
    </message>
    <message>
        <location filename="messages.py" line="164"/>
        <source>Raster not found or clip failed</source>
        <translation>Ráster no encontrada o falló el corte</translation>
    </message>
    <message>
        <location filename="messages.py" line="167"/>
        <source>Shapefile or raster not found</source>
        <translation>Archivo shape o ráster no encontrada</translation>
    </message>
    <message>
        <location filename="messages.py" line="170"/>
        <source>Error deleting ROI</source>
        <translation>Error eliminando ROI</translation>
    </message>
    <message>
        <location filename="messages.py" line="173"/>
        <source>The Macroclass field is missing</source>
        <translation>Falta el campo Macroclass</translation>
    </message>
    <message>
        <location filename="messages.py" line="176"/>
        <source>Error saving signatures</source>
        <translation>Error guardando firmas</translation>
    </message>
    <message>
        <location filename="messages.py" line="179"/>
        <source>Error opening signatures</source>
        <translation>Error abriendo firmas</translation>
    </message>
    <message>
        <location filename="messages.py" line="182"/>
        <source>Error opening spectral library</source>
        <translation>Error abriendo librería espectral</translation>
    </message>
    <message>
        <location filename="messages.py" line="185"/>
        <source>Error saving spectral library</source>
        <translation>Error guardando librería espectral</translation>
    </message>
    <message>
        <location filename="messages.py" line="188"/>
        <source>Import failed</source>
        <translation>Falló la importación</translation>
    </message>
    <message>
        <location filename="messages.py" line="191"/>
        <source>ROI creation failed</source>
        <translation>Falló la creación del ROI</translation>
    </message>
    <message>
        <location filename="messages.py" line="194"/>
        <source>Internet connection failed</source>
        <translation>Falló la conexión a internet</translation>
    </message>
    <message>
        <location filename="messages.py" line="197"/>
        <source>Exporting Log file failed</source>
        <translation>Falló exportar archivo Log</translation>
    </message>
    <message>
        <location filename="messages.py" line="200"/>
        <source>Saving algorithm files failed</source>
        <translation>Falló el guardado del algoritmo</translation>
    </message>
    <message>
        <location filename="messages.py" line="203"/>
        <source>Unable to get ROI attributes; check training shapefiles field names</source>
        <translation>Imposible obtener atributos del ROI; verifica los nombres de campo del archivo shape de entrada</translation>
    </message>
    <message>
        <location filename="messages.py" line="209"/>
        <source>Error reading raster. Possibly the raster path contains unicode characters</source>
        <translation>Error leyendo ráster. Posiblemente la ruta contiene caracteres unicode</translation>
    </message>
    <message>
        <location filename="messages.py" line="212"/>
        <source>The version of Numpy is outdated. Please install QGIS using OSGEO4W for an updated version of Numpy or visit http://fromgistors.blogspot.com/p/frequently-asked-questions.html#numpy_version</source>
        <translation>La versión de Numpy está desactualizada. Por favor instala QGIS usando OSGEO4W para una versión actualizada de Numpy o visita http://fromgistors.blogspot.com/p/frequently-asked-questions.html#numpy_version</translation>
    </message>
    <message>
        <location filename="messages.py" line="215"/>
        <source>Unable to perform operation. Possibly OGR is missing drivers. Please repeat QGIS installation.</source>
        <translation>Imposible realizar la operación. Posiblemente existen controladores perdidos de OGR. Por favor repite la instalación de QGIS.</translation>
    </message>
    <message>
        <location filename="messages.py" line="218"/>
        <source>Memory error. Please, set a lower value of RAM in the tab Settings.</source>
        <translation>Error de memoria. Por favor, establece un valor de RAM más bajo en la pestaña Configuración.</translation>
    </message>
    <message>
        <location filename="messages.py" line="221"/>
        <source>Edge error. Reduce the ROI width or draw a ROI manually (recommended installation of GDAL &gt;= 1.10)</source>
        <translation>Error de borde. Reduce el ancho de ROI o dibuja manualmente el ROI (es recomendable instalar GDAL &gt;= 1.10)</translation>
    </message>
    <message>
        <location filename="messages.py" line="224"/>
        <source>Unable to proceed. Rename the Landsat bands with a file name ending with the band number (e.g. rename B20 to B2)</source>
        <translation>Imposible continuar. Cambia el nombre a las bandas Landsat con un nombre de archivo terminado en el número de banda (Ej. cambia B20 por B2)</translation>
    </message>
    <message>
        <location filename="messages.py" line="227"/>
        <source>Error calculating signature. Possibly ROI is too small</source>
        <translation>Error calculando firmas. Tal vez el ROI es demasiado pequeño</translation>
    </message>
    <message>
        <location filename="messages.py" line="230"/>
        <source>Unable to split bands</source>
        <translation>Imposible separar las bandas</translation>
    </message>
    <message>
        <location filename="messages.py" line="233"/>
        <source>Error reading band set. Possibly raster files are not loaded</source>
        <translation>Error leyendo el Juego de Bandas. Es posible que los archivos ráster no se hayan cargado</translation>
    </message>
    <message>
        <location filename="messages.py" line="236"/>
        <source>Clip area outside image. Check the raster projection</source>
        <translation>Area de corte fuera de la imagen. Revisa la proyección del ráster</translation>
    </message>
    <message>
        <location filename="messages.py" line="239"/>
        <source>Unable to merge. Signatures have different unit or wavelength</source>
        <translation>Imposible combinar. Las Firmas tienen diferente unidad de longitud de onda</translation>
    </message>
    <message>
        <location filename="messages.py" line="242"/>
        <source>Unable to calculate. Expression error</source>
        <translation>Imposible calcular. Error en la expresión</translation>
    </message>
    <message>
        <location filename="messages.py" line="245"/>
        <source>Unable to calculate. Metadata error</source>
        <translation>Imposible calcular. Error en metadatos</translation>
    </message>
    <message>
        <location filename="messages.py" line="251"/>
        <source>Unable to find images</source>
        <translation>Imposible encontrar imágenes</translation>
    </message>
    <message>
        <location filename="messages.py" line="254"/>
        <source>Unable to connect</source>
        <translation>Imposible conectar</translation>
    </message>
    <message>
        <location filename="messages.py" line="257"/>
        <source>Unable to load image</source>
        <translation>Imposible cargar imagen</translation>
    </message>
    <message>
        <location filename="messages.py" line="263"/>
        <source>Attribute table error</source>
        <translation>Error en tabla de atributos</translation>
    </message>
    <message>
        <location filename="messages.py" line="266"/>
        <source>Unable to pansharpen: missing bands </source>
        <translation>Imposible realizar pansharpen: bandas ausentes</translation>
    </message>
    <message>
        <location filename="messages.py" line="269"/>
        <source>Unable to calculate</source>
        <translation>Imposible calcular</translation>
    </message>
    <message>
        <location filename="messages.py" line="272"/>
        <source>Error reading raster. Possibly bands are not aligned</source>
        <translation>Error leyendo ráster. Es posible que las bandas no estén alineadas</translation>
    </message>
    <message>
        <location filename="messages.py" line="275"/>
        <source>Unable to get raster projection. Try to reproject the raster</source>
        <translation>Imposible obtener la proyección del ráster. Intenta reproyectar el ráster</translation>
    </message>
    <message>
        <location filename="messages.py" line="278"/>
        <source>Error calculating accuracy. Possibly shapefile polygons are outside classification</source>
        <translation>Error calculando precisión. Es posible que los polígonos del archivo shape estén afuera de la clasificación</translation>
    </message>
    <message>
        <location filename="messages.py" line="281"/>
        <source>Unable to connect. Check user name and password</source>
        <translation>Imposible conectar. Verifica el nombre de usuario y la contraseña</translation>
    </message>
    <message>
        <location filename="messages.py" line="287"/>
        <source>No metadata found inside the input directory (a .xml file whose name contains MTD_L1C)</source>
        <translation>No se encontró metadatos en el directorio de entrada (archivo .xml cuyo nombre contiene MTD_L1C)</translation>
    </message>
    <message>
        <location filename="messages.py" line="290"/>
        <source>No metadata found inside the input directory (a .xml file whose name contains MTD_SAFL1C)</source>
        <translation>No se encontró metadatos en el directorio de entrada (archivo .xml cuyo nombre contiene MTD_SAFL1C)</translation>
    </message>
    <message>
        <location filename="messages.py" line="293"/>
        <source>Memory error. Please, decrease decimal precision</source>
        <translation>Error de memoria. Por favor, disminuye la precisión decimal</translation>
    </message>
    <message>
        <location filename="messages.py" line="296"/>
        <source>Error calculating plot</source>
        <translation>Error calculando el gráfico</translation>
    </message>
    <message>
        <location filename="messages.py" line="302"/>
        <source>SSL connection error. Please see the FAQ of the plugin user manual for solving this</source>
        <translation>Error de conexión SSL. Por favor mira las FAQ o el Manual del Usuario del complemento para resolver esto</translation>
    </message>
    <message>
        <location filename="messages.py" line="385"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="messages.py" line="321"/>
        <source>It appears that SciPy is not correctly installed. Please, update QGIS </source>
        <translation>Parece que SciPy no está instalado correctamente. Por favor, actualiza QGIS</translation>
    </message>
    <message>
        <location filename="messages.py" line="324"/>
        <source>It appears that SciPy is not correctly installed. Please, see this page for information about SciPy installation </source>
        <translation>Parece que SciPy no está instalado correctamente. Por favor, mira esta página con información sobre la instalación de SciPy</translation>
    </message>
    <message>
        <location filename="messages.py" line="327"/>
        <source>rasters have different pixel sizes that can lead to incorrect results. Please, consider to resample rasters to the same pixel size</source>
        <translation>los rásters tienen diferentes tamaños de pixel lo que puede producir resultados incorrectos. Por favor, considere remuestrear los rásters al mismo tamaño de pixel</translation>
    </message>
    <message>
        <location filename="messages.py" line="330"/>
        <source>The same ID class has been already assigned to a different macrolass</source>
        <translation>El mismo ID de Clase ya ha sido asignado a una Macroclase diferente </translation>
    </message>
    <message>
        <location filename="messages.py" line="333"/>
        <source>Wavelength already present</source>
        <translation>Longitud de onda ya presente</translation>
    </message>
    <message>
        <location filename="messages.py" line="336"/>
        <source>Wavelength unit not provided in band set</source>
        <translation>No se ha indicado la unidad de longitud de onda en el Juego de Bandas</translation>
    </message>
    <message>
        <location filename="messages.py" line="346"/>
        <source>RAM value was too high. Value has been decreased automatically</source>
        <translation>El valor de RAM era demasiado alto. El valor se ha disminuido automáticamente</translation>
    </message>
    <message>
        <location filename="messages.py" line="352"/>
        <source>Unable to load the virtual raster. Please create it manually</source>
        <translation>Imposible cargar el ráster virtual. Por favor procede a crearlo manualmente</translation>
    </message>
    <message>
        <location filename="messages.py" line="355"/>
        <source>Unable to proceed. The raster must be in projected coordinates</source>
        <translation>Imposible continuar. El ráster debe estar en coordenadas proyectadas</translation>
    </message>
    <message>
        <location filename="messages.py" line="358"/>
        <source>Select at least one raster</source>
        <translation>Selecciona al menos un ráster</translation>
    </message>
    <message>
        <location filename="messages.py" line="361"/>
        <source>Incorrect expression</source>
        <translation>Expresión incorrecta</translation>
    </message>
    <message>
        <location filename="messages.py" line="364"/>
        <source>Unable to access the temporary directory</source>
        <translation>Imposible acceder al directorio temporal</translation>
    </message>
    <message>
        <location filename="messages.py" line="367"/>
        <source>Reduce the search area extent within 10 degrees of latitude and 10 degrees of longitude</source>
        <translation>Reduce la extensión del área de búsqueda en 10 grados de latitud y 10 grados de longitud</translation>
    </message>
    <message>
        <location filename="messages.py" line="370"/>
        <source>Macroclass symbology is missing</source>
        <translation>No se encuentra la simbología de la Macroclase</translation>
    </message>
    <message>
        <location filename="messages.py" line="373"/>
        <source>Missing bands</source>
        <translation>Bandas perdidas</translation>
    </message>
    <message>
        <location filename="messages.py" line="376"/>
        <source>No metadata found inside the input directory. Default values will be used</source>
        <translation>No se encuentran metadatos en el directorio de entrada. Se usarán los valores por defecto</translation>
    </message>
    <message>
        <location filename="signature_importer.py" line="185"/>
        <source>Select a shapefile</source>
        <translation>Selecciona un archivo shape</translation>
    </message>
    <message>
        <location filename="utils.py" line="2192"/>
        <source>Please wait ...</source>
        <translation>Por favor espera ...</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1163"/>
        <source>Set thresholds</source>
        <translation>Establecer umbrales</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1163"/>
        <source>Are you sure you want to set thresholds for several signatures?</source>
        <translation>¿Estás seguro que quieres establecer umbrales para varias firmas?</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="67"/>
        <source>Save error matrix raster output</source>
        <translation>Guardar matriz de error ráster</translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="304"/>
        <source>Classification</source>
        <translation>Classificación</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="284"/>
        <source>ErrMatrixCode</source>
        <translation>ErrMatrixCode</translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="333"/>
        <source>Reference</source>
        <translation>Referencia</translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>PixelSum</source>
        <translation>PixelSum</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="307"/>
        <source>ERROR MATRIX</source>
        <translation>MATRIZ DE ERROR</translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="356"/>
        <source>Total</source>
        <translation>Total</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="349"/>
        <source>Overall accuracy [%] = </source>
        <translation>Precisión total [%] =</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="367"/>
        <source>Class </source>
        <translation>Clase</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="367"/>
        <source> producer accuracy [%] = </source>
        <translation>precisión del productor [%] =</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="367"/>
        <source> user accuracy [%] = </source>
        <translation>precisión del usuario [%] =</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="367"/>
        <source>Kappa hat = </source>
        <translation>Coeficiente Kappa =</translation>
    </message>
    <message>
        <location filename="accuracy.py" line="374"/>
        <source>Kappa hat classification = </source>
        <translation>Clasificación Kappa =</translation>
    </message>
    <message>
        <location filename="algorithmWeightTab.py" line="84"/>
        <source>Reset weights</source>
        <translation>Restaurar pesos</translation>
    </message>
    <message>
        <location filename="algorithmWeightTab.py" line="84"/>
        <source>Are you sure you want to reset weights?</source>
        <translation>¿Estás seguro que quieres restaurar los pesos?</translation>
    </message>
    <message>
        <location filename="modisTab.py" line="46"/>
        <source>Select a HDF file</source>
        <translation>Selecciona un archivo HDF</translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="99"/>
        <source>Clear rules</source>
        <translation>Borrar reglas</translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="99"/>
        <source>Are you sure you want to clear the rules?</source>
        <translation>¿Estás seguro que quieres borrar las reglas?</translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="175"/>
        <source>Select a text file of rules</source>
        <translation>Selecciona un archivo de reglas</translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="209"/>
        <source>Save the rules to file</source>
        <translation>Guarda las reglas en un archivo</translation>
    </message>
    <message>
        <location filename="vectortorasterTab.py" line="65"/>
        <source>Save raster output</source>
        <translation>Guarda el ráster de salida</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="159"/>
        <source>Select a raster</source>
        <translation>Selecciona un ráster</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="313"/>
        <source>Clear band set</source>
        <translation>Borrar juego de bandas</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="313"/>
        <source>Are you sure you want to clear the band set?</source>
        <translation>¿Estás seguro que quieres borrar el juego de bandas?</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="491"/>
        <source>Save the band set to file</source>
        <translation>Guardar el juego de bandas a un archivo</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="524"/>
        <source>Select a band set file</source>
        <translation>Selecciona un archivo de juego de bandas</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="771"/>
        <source>Remove band</source>
        <translation>Quitar banda</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="771"/>
        <source>Are you sure you want to remove the selected bands from band set?</source>
        <translation>¿Estás seguro que quieres quitar las bandas seleccionadas del juego de bandas?</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="819"/>
        <source>Save virtual raster</source>
        <translation>Guardar ráster virtual</translation>
    </message>
    <message>
        <location filename="stackrasterbands.py" line="154"/>
        <source>Save raster</source>
        <translation>Guardar ráster</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="890"/>
        <source>Build overviews</source>
        <translation>Construir vistas generales</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="890"/>
        <source>Do you want to build the external overviews of bands?</source>
        <translation>¿Quieres construir vistas generales externas?</translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="903"/>
        <source> building overviews</source>
        <translation>construir vistas generales</translation>
    </message>
    <message>
        <location filename="batchTab.py" line="129"/>
        <source>Select a batch file</source>
        <translation>Seleccionar un archivo de lotes</translation>
    </message>
    <message>
        <location filename="batchTab.py" line="136"/>
        <source>Save the batch to file</source>
        <translation>Guardar los lotes en un archivo</translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="47"/>
        <source>Save classification report</source>
        <translation>Guardar el reporte de clasificación</translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="54"/>
        <source>report</source>
        <translation>reporte</translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="263"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="111"/>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="111"/>
        <source>Percentage %</source>
        <translation>Porcentaje %</translation>
    </message>
    <message>
        <location filename="classtovectorTab.py" line="61"/>
        <source>Save shapefile output</source>
        <translation>Guardar archivo shape de salida</translation>
    </message>
    <message>
        <location filename="clipmultiplerasters.py" line="128"/>
        <source>Select a directory where to save clipped rasters</source>
        <translation>Selecciona un directorio para guardar los rásters cortados</translation>
    </message>
    <message>
        <location filename="sieveTab.py" line="51"/>
        <source>Save output</source>
        <translation>Guardar salida</translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="629"/>
        <source>Searching ...</source>
        <translation>Buscando ...</translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="353"/>
        <source>Download the images in the table (requires internet connection)</source>
        <translation>Descarga las imágenes de la tabla (se requiere conexión a internet)</translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="549"/>
        <source>Export download links</source>
        <translation>Exportar enlaces de descarga</translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="752"/>
        <source>Reset signature list</source>
        <translation>Restaurar lista de firmas</translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="752"/>
        <source>Are you sure you want to clear the table?</source>
        <translation>¿Estás seguro que quieres borrar la tabla?</translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="102"/>
        <source>Save land cover change raster output</source>
        <translation>Guardar el ráster de salida de la clasificación</translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>ChangeCode</source>
        <translation>ChangeCode</translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>ReferenceClass</source>
        <translation>ReferenceClass</translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>NewClass</source>
        <translation>NewClass</translation>
    </message>
    <message>
        <location filename="landsatTab.py" line="54"/>
        <source>Select a MTL file</source>
        <translation>Seleccionar archivo MTL</translation>
    </message>
    <message>
        <location filename="multipleroiTab.py" line="214"/>
        <source>Save the point list to file</source>
        <translation>Guardar la lista de puntos a un archivo</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="177"/>
        <source>Principal Components Analysis</source>
        <translation>Análisis de Componentes Principales</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="179"/>
        <source>Covariance matrix</source>
        <translation>Matriz de covarianza</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="202"/>
        <source>Bands</source>
        <translation>Bandas</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="191"/>
        <source>Correlation matrix</source>
        <translation>Matriz de correlación</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="200"/>
        <source>Eigen vectors</source>
        <translation>Vectores propios</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="204"/>
        <source>Vector_</source>
        <translation>Vector_</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="212"/>
        <source>Eigen values</source>
        <translation>Valores propios</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="212"/>
        <source>Accounted variance</source>
        <translation>Varianza explicada</translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="212"/>
        <source>Cumulative variance</source>
        <translation>Varianza acumulativa</translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="129"/>
        <source>Reset RGB list</source>
        <translation>Restaurar lista RGB</translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="129"/>
        <source>Are you sure you want to clear the RGB list?</source>
        <translation>¿Estás seguro de querer borrar la lista RGB?</translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="218"/>
        <source>RGB list</source>
        <translation>Lista RGB</translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="218"/>
        <source>Calculate all the RGB combinations?</source>
        <translation>¿Calcular todas las combinaciones RGB?</translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="243"/>
        <source>Save the RGB list to file</source>
        <translation>Guardar la lista RGB en un archivo</translation>
    </message>
    <message>
        <location filename="sentinelTab.py" line="54"/>
        <source>Select a XML file</source>
        <translation>Selecciona un archivo XML</translation>
    </message>
    <message>
        <location filename="settings.py" line="247"/>
        <source>Transparency </source>
        <translation>Transparencia</translation>
    </message>
    <message>
        <location filename="settings.py" line="72"/>
        <source>Save Log file</source>
        <translation>Guardar archivo de Log</translation>
    </message>
    <message>
        <location filename="settings.py" line="187"/>
        <source>Reset field names</source>
        <translation>Restaurar nombres de campo</translation>
    </message>
    <message>
        <location filename="settings.py" line="187"/>
        <source>Are you sure you want to reset field names?</source>
        <translation>¿Estás seguro que quieres restaurar los nombres de campo?</translation>
    </message>
    <message>
        <location filename="settings.py" line="198"/>
        <source>Reset variable name</source>
        <translation>Restaurar el nombre de la variable</translation>
    </message>
    <message>
        <location filename="settings.py" line="198"/>
        <source>Are you sure you want to reset variable name?</source>
        <translation>¿Estás seguro que quieres restaurar el nombre de la variable?</translation>
    </message>
    <message>
        <location filename="settings.py" line="206"/>
        <source>Reset group name</source>
        <translation>Restaurar nombre de grupo</translation>
    </message>
    <message>
        <location filename="settings.py" line="206"/>
        <source>Are you sure you want to reset group name?</source>
        <translation>¿Estás seguro que quieres restaurar el nombre del grupo?</translation>
    </message>
    <message>
        <location filename="settings.py" line="214"/>
        <source>Change temporary directory</source>
        <translation>Cambiar directorio temporal</translation>
    </message>
    <message>
        <location filename="settings.py" line="214"/>
        <source>Are you sure you want to change the temporary directory?</source>
        <translation>¿Estás seguro que quieres cambiar el directorio temporal?</translation>
    </message>
    <message>
        <location filename="settings.py" line="232"/>
        <source>Reset temporary directory</source>
        <translation>Restaurar directorio temporal</translation>
    </message>
    <message>
        <location filename="settings.py" line="232"/>
        <source>Are you sure you want to reset the temporary directory?</source>
        <translation>¿Estás seguro que quieres restaurar el directorio temporal?</translation>
    </message>
    <message>
        <location filename="signatureThresholdTab.py" line="120"/>
        <source>Reset thresholds</source>
        <translation>Restaurar umbrales</translation>
    </message>
    <message>
        <location filename="signatureThresholdTab.py" line="120"/>
        <source>Are you sure you want to reset thresholds?</source>
        <translation>¿Estás seguro que quieres restaurar los umbrales?</translation>
    </message>
    <message>
        <location filename="scatter_plot.py" line="484"/>
        <source>Delete scatter plot</source>
        <translation>Eliminar gráfico de dispersión</translation>
    </message>
    <message>
        <location filename="scatter_plot.py" line="484"/>
        <source>Are you sure you want to delete highlighted scatter plots?</source>
        <translation>¿Estás seguro que quieres eliminar los gráficos de dispersión seleccionados?</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="206"/>
        <source>Save plot to file</source>
        <translation>Guardar gráfico en archivo</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="87"/>
        <source>Edit value range</source>
        <translation>Editar rango de valores</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="87"/>
        <source>Are you sure you want to edit the value range for several signatures?</source>
        <translation>¿Estás seguro que quieres editar el rango de valores para varias firmas?</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="233"/>
        <source>Add to Signature list</source>
        <translation>Agregar a la lista de Firmas</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="233"/>
        <source>Are you sure you want to add highlighted signatures to the list?</source>
        <translation>¿Estás seguro que quieres agregar las firmas seleccionadas a la lista?</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="470"/>
        <source>Are you sure you want to delete highlighted signatures?</source>
        <translation>¿Estás seguro que quieres borrar las firmas seleccionadas?</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="627"/>
        <source>Values</source>
        <translation>Valores</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1035"/>
        <source>Undo thresholds</source>
        <translation>Deshacer umbrales</translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1035"/>
        <source>Are you sure you want to undo thresholds?</source>
        <translation>¿Estás seguro que quieres deshacer los umbrales?</translation>
    </message>
    <message>
        <location filename="messages.py" line="140"/>
        <source>ROI creation failed. <byte value="xd"/>
or <byte value="xd"/>
Possible reason: one or more band of the band set are missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="146"/>
        <source>Signature calculation failed. <byte value="xd"/>
Possible reason: the raster is not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="149"/>
        <source>Import failed. <byte value="xd"/>
Possible reason: selected file is not a band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="152"/>
        <source>Classification failed. <byte value="xd"/>
It appears the one or more bands of the band set are missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="155"/>
        <source>ROI creation failed. <byte value="xd"/>
Possible reason: input is a virtual raster or band is not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="360"/>
        <source>Landsat download</source>
        <translation type="unfinished">Descargar Landsat</translation>
    </message>
    <message>
        <location filename="input.py" line="362"/>
        <source>Sentinel-2 download </source>
        <translation type="unfinished">Sentinel-2 descarga</translation>
    </message>
    <message>
        <location filename="input.py" line="370"/>
        <source>Multiple ROI creation</source>
        <translation type="unfinished">Creación de ROI múltiples</translation>
    </message>
    <message>
        <location filename="input.py" line="372"/>
        <source>Import signatures</source>
        <translation type="unfinished">Importar firmas</translation>
    </message>
    <message>
        <location filename="input.py" line="374"/>
        <source>Export signatures</source>
        <translation type="unfinished">Exportar librerías</translation>
    </message>
    <message>
        <location filename="input.py" line="376"/>
        <source>Algorithm band weight</source>
        <translation type="unfinished">Algoritmo peso de banda</translation>
    </message>
    <message>
        <location filename="input.py" line="378"/>
        <source>Signature threshold</source>
        <translation type="unfinished">Umbral de firma</translation>
    </message>
    <message>
        <location filename="input.py" line="380"/>
        <source>LCS threshold</source>
        <translation type="unfinished">Umbral LCS</translation>
    </message>
    <message>
        <location filename="input.py" line="386"/>
        <source>Landsat</source>
        <translation type="unfinished">Landsat</translation>
    </message>
    <message>
        <location filename="input.py" line="388"/>
        <source>Sentinel-2</source>
        <translation type="unfinished">Sentinel-2</translation>
    </message>
    <message>
        <location filename="input.py" line="390"/>
        <source>ASTER</source>
        <translation type="unfinished">ASTER</translation>
    </message>
    <message>
        <location filename="input.py" line="394"/>
        <source>Clip multiple rasters</source>
        <translation type="unfinished">Recortar múltiples rásters</translation>
    </message>
    <message>
        <location filename="input.py" line="396"/>
        <source>Split raster bands</source>
        <translation type="unfinished">Separar bandas ráster</translation>
    </message>
    <message>
        <location filename="input.py" line="400"/>
        <source>PCA</source>
        <translation type="unfinished">PCA</translation>
    </message>
    <message>
        <location filename="input.py" line="402"/>
        <source>Vector to raster</source>
        <translation type="unfinished">Vectorial a ráster</translation>
    </message>
    <message>
        <location filename="input.py" line="406"/>
        <source>Accuracy</source>
        <translation type="unfinished">Precisión</translation>
    </message>
    <message>
        <location filename="input.py" line="408"/>
        <source>Land cover change</source>
        <translation type="unfinished">Cambio de cobertura del suelo</translation>
    </message>
    <message>
        <location filename="input.py" line="410"/>
        <source>Classification report</source>
        <translation type="unfinished">Reporte de la clasificación</translation>
    </message>
    <message>
        <location filename="input.py" line="414"/>
        <source>Classification to vector</source>
        <translation type="unfinished">Clasificación a vectorial</translation>
    </message>
    <message>
        <location filename="input.py" line="416"/>
        <source>Reclassification</source>
        <translation type="unfinished">Reclasificación</translation>
    </message>
    <message>
        <location filename="input.py" line="418"/>
        <source>Edit raster</source>
        <translation type="unfinished">Editar ráster</translation>
    </message>
    <message>
        <location filename="input.py" line="420"/>
        <source>Classification sieve</source>
        <translation type="unfinished">Filtrado de la Clasificación</translation>
    </message>
    <message>
        <location filename="input.py" line="422"/>
        <source>Classification erosion</source>
        <translation type="unfinished">Erosión de la clasificación</translation>
    </message>
    <message>
        <location filename="input.py" line="424"/>
        <source>Classification dilation</source>
        <translation type="unfinished">Dilatación de la Clasificación</translation>
    </message>
    <message>
        <location filename="input.py" line="455"/>
        <source>About</source>
        <translation type="unfinished">Acerca de</translation>
    </message>
    <message>
        <location filename="input.py" line="364"/>
        <source>ASTER download</source>
        <translation type="unfinished">ASTER descarga</translation>
    </message>
    <message>
        <location filename="input.py" line="436"/>
        <source>Interface</source>
        <translation type="unfinished">Interfaz</translation>
    </message>
    <message>
        <location filename="input.py" line="441"/>
        <source>Processing</source>
        <translation type="unfinished">Procesado</translation>
    </message>
    <message>
        <location filename="input.py" line="446"/>
        <source>Debug</source>
        <translation type="unfinished">Depurar</translation>
    </message>
    <message>
        <location filename="messages.py" line="379"/>
        <source>The coordinate system of training input is different from the input image. Please create a new training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="308"/>
        <source>Directory error. Check write permission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="255"/>
        <source>Value 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="256"/>
        <source>Set value 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="258"/>
        <source>Value 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="259"/>
        <source>Set value 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="261"/>
        <source>Value 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="262"/>
        <source>Set value 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="263"/>
        <source>Undo edit (only for ROI polygons)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="311"/>
        <source>Error accessing training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="314"/>
        <source>Rasters appear to be in different projections. Reproject rasters to the same CRS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="385"/>
        <source>Search error HTTP Status 500, reduce the result number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="67"/>
        <source>Save cross classification raster output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="304"/>
        <source>CrossClassCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="crossclassificationTab.py" line="327"/>
        <source>CROSS MATRIX [</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="412"/>
        <source>Cross classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="457"/>
        <source>Show plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="366"/>
        <source>MODIS download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="392"/>
        <source>MODIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="398"/>
        <source>Stack raster bands</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
